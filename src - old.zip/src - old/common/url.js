import {Store} from '@common';

const url = {
    imageuploadurl : Store.baseurl+'customers/imageupload',
    updateuseraddress : Store.baseurl+'customers/',
    createnewuserurl : Store.baseurl+'auth/register',
    bannerurl : Store.baseurl+'banners',
    loginurl : Store.baseurl + 'auth/login',
    newaccounturl : Store.baseurl + 'auth/register',
    menulisturl : Store.baseurl+'menu/list',
    phonenumberauthurl : Store.baseurl+'auth/phoneauth',
    otpverifyurl : Store.baseurl+'auth/phoneauthvalidation',
    updateuserinfourl : Store.baseurl+'customers/',
    neworderurl : Store.baseurl+'orders',
    rateusurl : 'http://www.artest.softmint.net/abc.html',
    privacypolicyurl : 'https://www.softmint.net/privacypolicy',
    restaurantlisturl : Store.baseurl+'restaurant/list',
    locationupdateurl : Store.baseurl+'customers/',
    googleauthurl : Store.baseurl+'auth/googleauth',
    getorderdetailsurl : Store.baseurl+'orders/getOrderDetails',
    getalloffersurl : Store.baseurl+'offers/getalloffers',
    getrestaurantdetailsurl : Store.baseurl+'restaurant/getrestaurantdetails',
    getesttimeurl : Store.baseurl+'orders/getDeliveryTime',
    getcustomerordersdetailurl : Store.baseurl+'orders/getCustomerOrderDetails',
    rateorderurl : Store.baseurl+'orders/rateOrder',
    deliveryareaurl : Store.baseurl+'deliveryarea',
    categorymenulisturl : Store.baseurl+'food/list',
    categoriesurl : Store.baseurl+'menu/categories',
}

export default url;