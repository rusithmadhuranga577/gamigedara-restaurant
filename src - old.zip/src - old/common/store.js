/**@format */
import Languages from "./languages";

const Icons = {
    storename : Languages.RestaurantName,
    storeaddress : Languages.RestaurantAddress,
    baseurl : 'https://www.gemigedara.lk/api/',
    mapsapi : 'AIzaSyDhIioyeLK_2jYbUprYP4gm0fc5oogav6Q',
    merchantlat : 7.487150,
    merchantlan : 80.364990,
}
export default Icons;