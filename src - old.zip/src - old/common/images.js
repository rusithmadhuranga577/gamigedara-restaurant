/**@format */

const Images = {
    SplashBg : require('@images/splash.jpeg'),
    GoogleIcon : require('@images/buttonimages/google.png'),
    FacebookIcon : require('@images/buttonimages/facebook.png'),
    UsernamePassword : require('@images/buttonimages/usernamepassword.png'),
    PhoneIcon : require('@images/buttonimages/phone.png'),
    Logo : require('@images/logo.png'),
    UserLocationMarker : require('@images/userlocation.png'),
    UserPlaceHolder : 'http://gamigedara.foodsmint.com/uploads/userplaceholder.png',
    BannerImage : require('@images/banner.jpg'),
    FlashImage : require('@images/flash.png'),
    Direction : require('@images/direction.png'),
    orderpending : require('@images/orderstatus/pending.png'),
    orderconfirmed : require('@images/orderstatus/confirmed.png'),
    orderpreparing : require('@images/orderstatus/preparing.png'),
    orderprepared : require('@images/orderstatus/prepared.png'),
    orderdelivered : require('@images/orderstatus/delivered.png'),
    drivericon : 'https://image.freepik.com/free-vector/delivery-man-riding-red-scooter-illustration_9845-14.jpg',
    storelistempty : require('@images/storesempty.png'),
    foodicon : require('@images/foodvector.png'),
    groceryicon : require('@images/groceryvector.png'),
    orderplacefailed : require('@images/orderplacefailed.png'),
    ordepack : require('@images/orderpackvector.png'),
    deliveryboy : require('@images/deliveryboyvector.png'),
}
export default Images;