/**@format */

const Icons = {
    at : require('@icons/at.svg'),
    userlocationmapicon : require('@icons/userlocationmapicon.png'),
    merchantlocationmapicon : require('@icons/merchantlocationmapicon.png'),
    cardpayment : require('@icons/cardpayment.png'),
    cashpayment : require('@icons/cash.png'),
    oldphone : require('@icons/oldphone.png'),
    deliveryboymapmarker : require('@icons/deliveryboymapmarker.png'),
    clearlisticon : require('@icons/clearlist.png')
}
export default Icons;