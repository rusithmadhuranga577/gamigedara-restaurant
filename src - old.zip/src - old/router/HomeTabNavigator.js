import React, {useEffect, useState} from 'react';
import {SafeAreaView, Dimensions} from 'react-native';
import AsyncStorage from '@react-native-community/async-storage';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { useNavigation } from '@react-navigation/native';
import firestore from '@react-native-firebase/firestore';
import Ionicons from 'react-native-vector-icons/Ionicons'; 
import styles from './styles';

import { Colors, Constants } from '@common'

import {Account} from '@screens';
import {Offers} from '@screens';
import {MulirestaurantHome} from '@screens';
import {OrdersScreen} from '@screens';


function HomeTabNavigator() {

    const [orderscount, setorderscount] = useState();
    const navigation = useNavigation();

    useEffect(()=>{
        AsyncStorage.getItem('userid', (err, userid) => {
            // console.log('userid',userid)
            const uid = Number(userid);
            firestore()
            .collection('orders')
            .where('status', '<', 6)
            .where('customer_id', '==', uid)
            .onSnapshot(documentSnapshot => {
                if(documentSnapshot != null){
                    if(documentSnapshot._docs.length != 0){
                        const count = documentSnapshot._docs.length;
                        setorderscount(count);
                    }else{
                        setorderscount(null);
                    }
                }
            }) 
        })
    },)

    const Tab = createBottomTabNavigator();
  
    return (
        <SafeAreaView style={{width : '100%', height : Dimensions.get('screen').height}}>
            <Tab.Navigator
                screenOptions={({ route }) => ({
                tabBarStyle: [styles.tabBarStyle],
                unmountInactiveRoutes: true,
                tabBarIcon: ({ focused, color, size }) => {
                    let iconName;
            
                    if (route.name === 'Home') {
                    iconName = focused ? 'home' : 'home';
                    color = focused ? Colors.primary : Colors.black;

                    }else if (route.name === 'Account') {
                    iconName = focused ? 'person' : 'person';
                    color = focused ? Colors.primary : Colors.black;

                    }else if (route.name === 'Offers') {
                    iconName = focused ? 'pricetag' : 'pricetag';
                    color = focused ? Colors.primary : Colors.black;
                    
                    }else if (route.name === 'Orders') {
                    iconName = focused ? 'list' : 'list';
                    color = focused ? Colors.primary : Colors.black;
                    }
            
                    return <Ionicons name={iconName} size={22} color={color} />;
                },
                })}
                tabBarOptions={{
                    labelStyle: [styles.hometabtitle],
                }}
                
            >
            <Tab.Screen name="Home" component={MulirestaurantHome} options={{headerShown : false}}/>
            <Tab.Screen name="Offers" component={Offers} options={{headerShown : false}}/>
            <Tab.Screen name="Orders" component={OrdersScreen} options={{headerShown : false, tabBarBadge: orderscount == 0 ? null : orderscount }}/>
            <Tab.Screen name="Account" component={Account} options={{headerShown : false}}/>
            </Tab.Navigator>
        </SafeAreaView>
    );
}

export default HomeTabNavigator;