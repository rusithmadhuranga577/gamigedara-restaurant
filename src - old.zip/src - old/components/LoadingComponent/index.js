/** @format */

import React, { useEffect, useState, useRef  } from 'react';
import {
  View,
  ActivityIndicator,
  Text
} from 'react-native';
import styles from './styles';
import { Images, Languages, Countries } from '@common';
import { Colors, Constants, Icons } from '@common';

const QueryString = require('query-string');

export default function LoadingComponent({
    visibility,
  }) {
    return (
      <>
        {visibility ? 
            <View style={[styles.overlay]}>
                <View style={[styles.indicatorholder]}>
                  <ActivityIndicator size={40} color={Colors.white} />
                  <Text style={[styles.text]}>{Languages.LoadingPleaseWait}</Text>
                </View>
            </View>:null
        }
      </>
    );
}