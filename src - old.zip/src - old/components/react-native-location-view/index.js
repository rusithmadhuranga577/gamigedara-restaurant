import LocationView from "./src/LocationView";

export default LocationView;