import React, { useEffect, useState } from 'react';
import { StyleSheet, View, Text, Image , Dimensions, LogBox  } from 'react-native';
import Carousel from 'react-native-banner-carousel-updated';
import SkeletonPlaceholder from "react-native-skeleton-placeholder";
import axios from 'axios';
import { Url, Images, Colors } from '@common';
import styles from './styles';

const BannerWidth = (Dimensions.get('window').width)-20;
const BannerHeight = 140;
const QueryString = require('query-string');

export default function OffersBanner({url}) {

  const [items, setItems] = useState([]);

  useEffect(() => {
      fetchData();
  }, [])

  const [isLoading, setLoading] = useState(true);

  const fetchData=()=>{
    axios.post(url, 
    QueryString.stringify({
    }), 
    {
        headers: {"Content-Type": "application/x-www-form-urlencoded",}
    }).then(response => {
      setItems(response.data.offers)
      setLoading(false);
    })
  }


  var images = []
  for( i=0; i < items.length; i++){
    images.push(items[i].image);
  }

  return (
      <View style={{width : '95%', alignSelf : 'center', elevation : 5, backgroundColor : Colors.gray}}>
        {isLoading ? 
          <SkeletonPlaceholder>
            <SkeletonPlaceholder.Item
              alignSelf={'center'}
              width={BannerWidth}
              height={BannerHeight}
              borderRadius={5}
            />
          </SkeletonPlaceholder>
            : 
          <Carousel
            autoplay
            autoplayTimeout={6000}
            loop
            index={0}
            pageSize={BannerWidth}
            useNativeDriver={false}
          >
              {images.map((image, index) => renderPage(image, index))}
          </Carousel>
            }
      </View>
    );

}

const renderPage = (image, index)=> {
    return (
      <View style={{ width: BannerWidth, height: BannerHeight, borderRadius : 5 }}  key={index}>
          <Image style={{ height: BannerHeight, borderRadius : 5 }} source={{ uri: image }} />
      </View>
  )
}