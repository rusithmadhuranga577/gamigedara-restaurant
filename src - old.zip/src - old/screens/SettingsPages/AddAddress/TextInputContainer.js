import React from 'react';
import {
  View,
  TextInput,
} from 'react-native';
import styles from './styles';

const QueryString = require('query-string');

class TextInputContainer extends React.Component {

    render(){
        return(
            <View>
                <TextInput
                    placeholder={this.props.placeholder}
                    style={[styles.inputcontainer]}
                    value={this.props.value}
                    onChangeText={(text)=>this.props.onChangeValue(text)}
                    keyboardType={this.props.type}
                    maxLength={this.props.maxLength}
                />
            </View>
        );
    }
    
}
export default TextInputContainer;