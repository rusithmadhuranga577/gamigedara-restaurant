import { StyleSheet, Dimensions } from "react-native"
import { Colors, Constants } from '@common';

const width = Dimensions.get('screen').width;
const itemlength = width/2.2

const styles = StyleSheet.create({
    container : {
        width: '100%', 
        height: itemlength,
        backgroundColor: Colors.backgroundgray,
        flexDirection : 'row',
        justifyContent : 'space-between',
        alignSelf : 'center',
        padding : 5
    },
    itemcontainer : {
        width: itemlength, 
        height: itemlength-30,
        margin : 5,
        borderRadius : 5,
        elevation : 8,
        padding : 5,
        backgroundColor : 'transparent'
    },
    itemtitlestyle : {
        fontFamily : Constants.fontFamilybold,
        fontSize : 20,
        color : Colors.white
    },
    imagecontainer : {
        width : 85,
        height: 90,
        position : 'absolute',
        bottom : 2,
        right : 2
    },
    image : {
        width : '100%',
        height : '100%'
    }
})

export default styles;