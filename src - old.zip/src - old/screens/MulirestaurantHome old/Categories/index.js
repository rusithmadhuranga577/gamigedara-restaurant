/** @format */

import React, { useEffect, useRef, useState } from 'react';
import { connect } from "react-redux";
import {
  Image,
  ScrollView,
  BackHandler,
  Text,
  FlatList,
  View,
} from 'react-native';
import styles from './styles';
import LinearGradient from 'react-native-linear-gradient';
import { useNavigation } from '@react-navigation/native';
import { TouchableOpacity } from 'react-native-gesture-handler';
import Geolocation from 'react-native-geolocation-service';

import { Images, Languages, Colors } from '@common';

const Categories =() => {

  const navigation = useNavigation();
  const [location, setlocation] =  useState([]);

  useEffect(() => {
        Geolocation.getCurrentPosition(
            position => {
                setlocation(position);
                console.log(position)
            },
            error => {
                alert(error.message.toString());
            },
            {
              showLocationDialog: true,
              enableHighAccuracy: true,
              timeout: 20000,
              maximumAge: 0,
            },
        );
  }, [])

  const Categories = [
      {
        id : 1,
        name : Languages.Eats,
        color : '#f1943c',
        image : Images.eatsimage
      },
      {
        id : 1,
        name : Languages.Grocery,
        color : '#f13c3c',
        image : Images.groceryimage
    },
    {
        id : 1,
        name : Languages.Fashions,
        color : '#00dcc3',
        image : Images.fashionimage
    },
  ]

  return(
    <View style={[styles.container]}>
        
        <TouchableOpacity activeOpacity={0.9} onPress={()=>navigation.push('RestaurantList', {type : 'restaurant', filter : 'nearest', lat : location.coords.latitude, lon : location.coords.longitude, dummydata : restaurantcatdata})}>
        <LinearGradient colors={[Categories[0].color, '#fff']} start={{ x: 0, y: 0 }} end={{ x: 0, y: 1.8 }} style={[styles.itemcontainer]} >
            <Text numberOfLines={1} style={[styles.itemtitlestyle]}>{Categories[0].name}</Text>
                <View style={[styles.imagecontainer]}>
                    <Image style={[styles.image]} source={Categories[0].image}/>
                </View>
        </LinearGradient >
        </TouchableOpacity>

        <TouchableOpacity activeOpacity={0.9} onPress={()=>navigation.push('RestaurantList', {type : 'grocery', filter : 'nearest', lat : location.coords.latitude, lon : location.coords.longitude, dummydata : grocerycatdata})}>
        <LinearGradient colors={[Categories[1].color, '#fff']} start={{ x: 0, y: 0 }} end={{ x: 0, y: 1.8 }} style={[styles.itemcontainer]} >
            <Text numberOfLines={1} style={[styles.itemtitlestyle]}>{Categories[1].name}</Text>
                <View style={[styles.imagecontainer]}>
                    <Image style={[styles.image]} source={Categories[0].image}/>
                </View>
        </LinearGradient >
        </TouchableOpacity>

        {/* <TouchableOpacity activeOpacity={0.9} onPress={()=>navigation.push('RestaurantList', {type : 'fashion', filter : 'nearest', lat : location.coords.latitude, lon : location.coords.longitude, dummydata : fashioncatdata})}>
        <LinearGradient colors={[Categories[2].color, '#fff']} start={{ x: 0, y: 0 }} end={{ x: 0, y: 1.8 }} style={[styles.itemcontainer]} >
            <Text numberOfLines={1} style={[styles.itemtitlestyle]}>{Categories[2].name}</Text>
                <View style={[styles.imagecontainer]}>
                    <Image style={[styles.image]} source={{uri : Categories[2].image}}/>
                </View>
        </LinearGradient >
        </TouchableOpacity> */}
    </View>
  );
}
export default Categories;