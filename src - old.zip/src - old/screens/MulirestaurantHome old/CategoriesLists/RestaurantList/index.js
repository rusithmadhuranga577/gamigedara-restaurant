import { View, Text, Image, TouchableOpacity, FlatList, Dimensions} from 'react-native';
import AsyncStorage from '@react-native-community/async-storage';
import React , { useState, useEffect } from 'react';
import { Images, Url } from '@common';
import styles from './styles';
import { useNavigation } from '@react-navigation/native';
import Geolocation from 'react-native-geolocation-service';
import { AirbnbRating } from 'react-native-ratings';
import { Clearcartpopup } from '@components';
import axios from 'axios';

const screenHeight = Dimensions.get('window').height;
var SharedPreferences = require('react-native-shared-preferences');
const QueryString = require('query-string');

function Restaurents({type}){

    const navigation = useNavigation();
    const [isLoading, setLoading] = useState(true);
    const [items, setItems] = useState([]);
    const [clearcartpopup, setclearcartpopup] = useState(false);
    const [clickedrestaurantid, setclickedrestaurantid]=useState('');
    const [clickedrestaurantfoodlist, setclickedrestaurantfoodlist]=useState([]);
    const [clickedrestauranttabs, setclickedrestauranttabs]=useState([]);
    const [clickedrestaurantimage, setclickedrestaurantimage]=useState('');
    const [clickedrestaurantdata, setclickedrestaurantdata]=useState([]);
    const [cartrestaurantid, setcartrestaurantid] = useState(null);

    useEffect(() => {
        Geolocation.getCurrentPosition(
            position => {
                axios.post(Url.restaurantlisturl, 
                QueryString.stringify({
                    filter : 'nearest',
                    type : type,
                    count : 5,
                    lat : position.coords.latitude,
                    lon : position.coords.longitude,
                }), 
                {
                    headers: {"Content-Type": "application/x-www-form-urlencoded",}
                }).then(response => {
                    setItems(response.data.data)
                })
            },
            error => {
                alert(error.message.toString());
            },
            {
            showLocationDialog: true,
            enableHighAccuracy: true,
            timeout: 20000,
            maximumAge: 0,
            },
        );
        
        SharedPreferences.getItem('cartrestaurantid', id=>{
            if(id != null){
                setcartrestaurantid(id);
            }else{
                setcartrestaurantid('no_cart_restaurant');
            }
        });
    }, []);

    const FetchMenuList=(id, image, item)=>{
        var foods = [];

        axios.post(Url.menulisturl, 
        QueryString.stringify({
        restaurant_id : id,
        }), 
        {
            headers: {"Content-Type": "application/x-www-form-urlencoded",}
        }).then(response => {
            foods = response.data;
            NavigateFunction(response.data, image, item, id)
        })
    }

    const NavigateFunction=(foods, image, item)=>{
        var tabtitles = [];
        for( i=0; i < foods.length; i++){
        tabtitles.push({cat_order : foods[i].catid, category_name : foods[i].title});
        }
        const res_id = item.id;
        const res_id_state = cartrestaurantid;
        if(res_id_state != 'no_cart_restaurant'){
            if(res_id != res_id_state){
                setclickedrestaurantid(res_id);
                setclickedrestaurantfoodlist(foods);
                setclickedrestauranttabs(tabtitles);
                setclickedrestaurantimage(image);
                setclickedrestaurantdata(item);
                OpenClearCartPopup();
            }else{
                navigation.push('MenuList', {menulist : foods, catid : 0, tabs : tabtitles, image : image, restaurantdata : item});
            }
        }else{
            navigation.push('MenuList', {menulist : foods, catid : 0, tabs : tabtitles, image : image, restaurantdata : item});
        }
    }

    const ClearCartAndNavigate=()=>{
        navigation.push('MenuList', {menulist : clickedrestaurantfoodlist, catid : 0, tabs : clickedrestauranttabs, image : clickedrestaurantimage, restaurantdata : clickedrestaurantdata});
    }
    
    const ClearCartFunction=()=>{
        AsyncStorage.removeItem('cartitems');
        SharedPreferences.removeItem('cartprice');
        SharedPreferences.removeItem('cartqty');
        SharedPreferences.removeItem('cartrestaurantid');
        setclearcartpopup(false);
        setcartrestaurantid('no_cart_restaurant');
        ClearCartAndNavigate();
    }
    
    const OpenClearCartPopup=()=>{
        setclearcartpopup(true);
    }
    
    const CloseClearCartPopup=()=>{
        setclearcartpopup(false);
    }

    return(
        <View>
            <FlatList
                horizontal
                itemDimension={80}
                data={items}
                style={styles.gridView}
                spacing={3}
                renderItem={({ item }) => (
                    <TouchableOpacity onPress={()=>FetchMenuList(item.id, item.cover_banner, item)} style={[styles.container]} >
                        <Image source={{uri : item.cover_banner}} style={[styles.image]}/>
                        <Text style={[styles.name]} numberOfLines={2}>{item.name}</Text>
                        <Text style={[styles.address]} numberOfLines={2}>{item.address_line_1}, {item.address_line_2}</Text>
                        <View style={[styles.startcontainer]}>
                        <AirbnbRating
                            size={15}
                            defaultRating={item.def_rating_count}
                            count={item.def_rating}
                            showRating={false}
                        />
                        </View>
                        <Image source={Images.Direction} style={[styles.directionimage]}/>
                    </TouchableOpacity>
                )}
            />

        {clearcartpopup ? 
        <Clearcartpopup ClearCart={ClearCartFunction} CancelLogout={CloseClearCartPopup} visibility={clearcartpopup} Closepopup={CloseClearCartPopup}/>
        :null}
        </View>
    );
}

export default Restaurents;