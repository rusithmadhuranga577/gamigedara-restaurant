/** @format */

import React, { useEffect, useRef, useState } from 'react';
import { connect } from "react-redux";
import {
    TouchableOpacity,
    Text,
    View,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import styles from '../styles';
import ListContainer from './ListContainer';
import { Images, Languages, Colors } from '@common';
import Geolocation from 'react-native-geolocation-service';

const restaurantcatdata = [
    {
        id : 1,
        name : 'Chinese',
        image : 'https://www.pngkey.com/png/full/286-2869600_pizza-take-pizza-vector.png'
    },
    {
        id : 2,
        name : 'Indian',
        image : 'https://www.pngkey.com/png/full/286-2869600_pizza-take-pizza-vector.png'
    },
    {
        id : 3,
        name : 'Pizza',
        image : 'https://www.pngkey.com/png/full/286-2869600_pizza-take-pizza-vector.png'
    },
    {
        id : 4,
        name : 'Seafood',
        image : 'https://www.pngkey.com/png/full/286-2869600_pizza-take-pizza-vector.png'
    },
    {
        id : 5,
        name : 'Chinese',
        image : 'https://www.pngkey.com/png/full/286-2869600_pizza-take-pizza-vector.png'
    },
    {
        id : 6,
        name : 'Indian',
        image : 'https://www.pngkey.com/png/full/286-2869600_pizza-take-pizza-vector.png'
    },
    {
        id : 7,
        name : 'Pizza',
        image : 'https://www.pngkey.com/png/full/286-2869600_pizza-take-pizza-vector.png'
    },
    {
        id : 8,
        name : 'Seafood',
        image : 'https://www.pngkey.com/png/full/286-2869600_pizza-take-pizza-vector.png'
    }
]

const grocerycatdata = [
    {
        id : 1,
        name : 'Vegitable',
        image : 'https://i.pinimg.com/originals/07/36/df/0736df35c198525e6493d648bf8fc38e.png'
    },
    {
        id : 2,
        name : 'Fruits',
        image : 'https://i.pinimg.com/originals/07/36/df/0736df35c198525e6493d648bf8fc38e.png'
    },
    {
        id : 3,
        name : 'Busicuit',
        image : 'https://i.pinimg.com/originals/07/36/df/0736df35c198525e6493d648bf8fc38e.png'
    },
    {
        id : 4,
        name : 'Fish',
        image : 'https://i.pinimg.com/originals/07/36/df/0736df35c198525e6493d648bf8fc38e.png'
    },
    {
        id : 5,
        name : 'Chocolate',
        image : 'https://i.pinimg.com/originals/07/36/df/0736df35c198525e6493d648bf8fc38e.png'
    },
    {
        id : 6,
        name : 'Cake',
        image : 'https://i.pinimg.com/originals/07/36/df/0736df35c198525e6493d648bf8fc38e.png'
    }
]

const fashioncatdata = [
    {
        id : 1,
        name : 'Ladies',
        image : 'https://icons.veryicon.com/png/o/clothes-accessories/spring-new-clothing/t-shirt-64.png'
    },
    {
        id : 2,
        name : 'Gents',
        image : 'https://icons.veryicon.com/png/o/clothes-accessories/spring-new-clothing/t-shirt-64.png'
    },
    {
        id : 3,
        name : 'Kids',
        image : 'https://icons.veryicon.com/png/o/clothes-accessories/spring-new-clothing/t-shirt-64.png'
    },
    {
        id : 4,
        name : 'Trending',
        image : 'https://icons.veryicon.com/png/o/clothes-accessories/spring-new-clothing/t-shirt-64.png'
    }
]

const CategoriesList =() => {

    const navigation = useNavigation();
    const [location, setlocation] =  useState([]);

    useEffect(()=>{
        Geolocation.getCurrentPosition(
            position => {
                setlocation(position);
            },
            error => {
                alert(error.message.toString());
            },
            {
              showLocationDialog: true,
              enableHighAccuracy: true,
              timeout: 20000,
              maximumAge: 0,
            },
        );
    },[])

    return(
        <View>
            <View style={{flexDirection : 'row', justifyContent : 'space-between'}}>
            <Text style={[styles.latestoffertext, {marginTop : 30}]}>{Languages.RestaurantsNearYou}</Text>
            <TouchableOpacity onPress={()=>navigation.push('RestaurantList', {type : 'restaurant', filter : 'nearest', lat : location.coords.latitude, lon : location.coords.longitude, dummydata : restaurantcatdata})} style={[styles.viewallbutton]}>
                <Text style={[styles.viewalltext]}>{Languages.ViewAll}</Text>
            </TouchableOpacity>
            </View>
            <ListContainer type={'restaurant'} location={JSON.stringify(location)} emptytext={Languages.NoRestaurants}/>

            <View style={{flexDirection : 'row', justifyContent : 'space-between'}}>
            <Text style={[styles.latestoffertext, {marginTop : 30}]}>{Languages.GroceriesNearYou}</Text>
            <TouchableOpacity onPress={()=>navigation.push('RestaurantList', {type : 'grocery', filter : 'nearest', lat : location.coords.latitude, lon : location.coords.longitude, dummydata : grocerycatdata})} style={[styles.viewallbutton]}>
                <Text style={[styles.viewalltext]}>{Languages.ViewAll}</Text>
            </TouchableOpacity>
            </View>
            <ListContainer type={'grocery'} location={JSON.stringify(location)} emptytext={Languages.NoGroceries}/>
        </View>
    );
}
export default CategoriesList;