import { StyleSheet, View, Text, Image, TouchableOpacity, Component, FlatList} from 'react-native';
import React , { useState, useEffect } from 'react';
import { Images, Languages, Colors, Constans, Url } from '@common';
import styles from './styles';
import { Rating, AirbnbRating } from 'react-native-ratings';
import Icon from 'react-native-vector-icons/FontAwesome5';
import Geolocation from 'react-native-geolocation-service';
import axios from 'axios';

const QueryString = require('query-string');

function FashionStores({location}){

    const [isLoading, setLoading] = useState(true);
    const [items, setItems] = useState([]);

    useEffect(() => {
        Geolocation.getCurrentPosition(
            position => {
                axios.post(Url.restaurantlisturl, 
                QueryString.stringify({
                    filter : 'nearest',
                    type : 'fashion',
                    count : 5,
                    lat : position.coords.latitude,
                    lon : position.coords.longitude,
                }), 
                {
                    headers: {"Content-Type": "application/x-www-form-urlencoded",}
                }).then(response => {
                    setItems(response.data.data)
                })
            },
            error => {
                alert(error.message.toString());
            },
            {
              showLocationDialog: true,
              enableHighAccuracy: true,
              timeout: 20000,
              maximumAge: 0,
            },
        );
    }, []);
  
      return(
          <View>
              <FlatList
                  horizontal
                  itemDimension={80}
                  data={items}
                  style={styles.gridView}
                  spacing={3}
                  renderItem={({ item }) => (
                      <TouchableOpacity style={[styles.container]} >
                          <Image source={{uri : item.cover_banner}} style={[styles.image]}/>
                          <Text style={[styles.name]} numberOfLines={2}>{item.name}</Text>
                          <Text style={[styles.address]} numberOfLines={2}>{item.address_line_1}, {item.address_line_2}</Text>
                          <View style={[styles.startcontainer]}>
                          <AirbnbRating
                              size={15}
                              defaultRating={item.def_rating_count}
                              count={item.def_rating}
                              showRating={false}
                          />
                          </View>
                          <Image source={Images.Direction} style={[styles.directionimage]}/>
                      </TouchableOpacity>
                  )}
              />
          </View>
      );
  }
  
export default FashionStores;