import { StyleSheet } from "react-native"
import { Colors, Constants } from '@common';
import { Dimensions } from "react-native";//94373164997

const screenwidth = Dimensions.get('window').width;

const styles = StyleSheet.create({
    container : {
        width: screenwidth/1.5, 
        height: screenwidth/2 - 10,
        backgroundColor: Colors.white,
        elevation : 8,
        margin : 10,
        borderRadius : 5,
        padding : 10
    },
    image : {
        width : '100%',
        height : '60%',
        borderRadius : 5,
        backgroundColor : Colors.gray
    },
    name : {
        fontFamily : Constants.fontFamilybold,
        fontSize : 13,
        color : Colors.black
    },
    address : {
        fontFamily : Constants.fontFamilynormal,
        fontSize : 10,
        color : Colors.black,
        marginTop : 5
    },
    directionimage : {
        width : 20, 
        height : 20,
        position : 'absolute',
        right : 20,
        top : 20
    },
    startcontainer : {
        flexDirection : 'row',
        alignItems : 'center',
        width : '80%',
        marginTop : 5
    }
})

export default styles;