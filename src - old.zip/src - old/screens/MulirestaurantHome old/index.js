/** @format */

import React, { useEffect, useRef, useState } from 'react';
import { connect } from "react-redux";
import {
  Linking,
  ScrollView,
  BackHandler,
  Text,
  Animated,
  View,
  TouchableOpacity
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import styles from './styles';
import AddressBar from './addressbar';
import NameBar from './namebar';
import CategoriesList from './CategoriesLists/index';
import Categories from "./Categories";
import { Images, Languages, Colors, Url } from '@common';
import firestore from '@react-native-firebase/firestore';
import { CustomAlert, CustomAlertButton } from '@components';
import { useIsFocused } from '@react-navigation/native';
import { Banner } from '@components';
import FloatinCartButton from './FloatingCartButton';
import OffersBanner from './OffersBanner';

var SharedPreferences = require('react-native-shared-preferences');

const Home =() => {
  const isFocused = useIsFocused();
  const navigation = useNavigation();
  const addressbarheight = useRef(new Animated.Value(0)).current;
  const ongoingcontaineropacity = useRef(new Animated.Value(0.5)).current;
  const [exitalert, setexitalert] = useState(false);
  const [showongoingcontainer, setshowongoingcontainer] = useState(false);
  const [selectedongoingorder, setselectedongoingorder] = useState(null);

  useEffect(() => {
    const backAction = () => {
      if (navigation.isFocused()) {
        setexitalert(true)
        return true;
      }
    };
    const backHandler = BackHandler.addEventListener("hardwareBackPress", backAction);
    SharedPreferences.getItem('userid', userid => {
      const uid = Number(userid);
      firestore()
      .collection('orders')
      .where('status', '<', 6)
      .where('customer_id', '==', '108')
      .onSnapshot(documentSnapshot => {
        if(documentSnapshot != null){
          if(documentSnapshot._docs.length != 0){
            setshowongoingcontainer(true);
            setselectedongoingorder(documentSnapshot._docs[0]._data.order_id);
            OngoingOrderContainerAnimation();
          }else{
            setshowongoingcontainer(false);
            Animated.timing(ongoingcontaineropacity, {
              toValue: 0, 
              duration: 2000,
            });
          }
        }
      })  
    })
    return () => backHandler.remove();
  }, [])

  const OngoingOrderContainerAnimation = () => {
    Animated.loop(
        Animated.sequence([
          Animated.timing(ongoingcontaineropacity, {
              toValue: 1, 
              duration: 200,
          }),
          Animated.timing(ongoingcontaineropacity, {
            toValue: 1, 
            duration: 2500,
          }),
          Animated.timing(ongoingcontaineropacity, {
            toValue: 0, 
            duration: 1000,
          }),
        ]),
    ).start();
  }

  const OngoingOrderContainer = () => {
    return(
      <Animated.View style={[styles.ongoingordercontainer, {opacity : ongoingcontaineropacity}]}>
      <TouchableOpacity onPress={()=>navigation.push('OrderStatus', {title : `#${selectedongoingorder} Order`, orderid : selectedongoingorder})}>
        <Text style={[styles.ongoingordertext]}>{Languages.YouHaveOngoing}</Text>
      </TouchableOpacity>
      </Animated.View>
    );
  }

  const AnimeateIn = () => {Animated.timing(addressbarheight,{toValue: -60,duration: 150}).start()}
  const Animeateout = () => {Animated.timing(addressbarheight,{toValue: 0,duration: 150}).start()}

  const onScroll = (e) => {
    const position = e.nativeEvent.contentOffset.y;
    if(position < 100){
      Animeateout();
    }else if(position > 60){
      AnimeateIn();
    }
  }

  return(
    <View style={[styles.container]}>
      <Animated.View style={{width : '100%', height : 60, transform : [{translateY : addressbarheight}], position : 'absolute', zIndex : 99}}>
        <AddressBar/>
      </Animated.View>
      <ScrollView
       onScroll={(e)=>onScroll(e)}
       showsVerticalScrollIndicator={false}
      >
        <NameBar/>
        <Banner url={Url.bannerurl}/>
        <View>
          <Text style={[styles.latestoffertext, {marginTop : 30}]}>{Languages.WhatWouldYouLike}</Text>
        </View>
        <Categories/>
        <CategoriesList/>
        <View>
          <Text style={[styles.latestoffertext, {marginBottom : 10, marginTop : 30}]}>{Languages.BestOffers}</Text>
        </View>
        <OffersBanner url={Url.getalloffersurl}/>
        <View style={{marginBottom : 50}}/>
      </ScrollView>

      <FloatinCartButton/>

      {/*Exit Alert*/}
      <CustomAlert
        displayMode={'alert'}
        displayMsg={Languages.YouWantToExitApp}
        displaymsgtitle={Languages.AreYouSure}
        visibility={exitalert}
        dismissAlert={setexitalert}
        cancellable={true}
        buttons={(
          <>
            <CustomAlertButton buttontitle={Languages.Yes} theme={'alert'} buttonaction={()=>BackHandler.exitApp()}/>
            <CustomAlertButton buttontitle={Languages.No} theme={'inverse'} buttonaction={()=>setexitalert(false)}/>
          </>
        )}
      />
      {showongoingcontainer ?
      <OngoingOrderContainer/>:null}
    </View>
  );
}
export default Home;