/** @format */

import React, { useEffect, useState } from 'react';
import { connect } from "react-redux";
import {
  SafeAreaView,
  ScrollView,
  Image,
  StyleSheet,
  Text,
  useColorScheme,
  View,
  TouchableOpacity
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useIsFocused } from '@react-navigation/native';
import styles from './styles';
import { Images, Languages } from '@common';

var SharedPreferences = require('react-native-shared-preferences');

const AddressBar =({height}) => {

  const navigation = useNavigation();
  const isFocused = useIsFocused();
  const [selfpickupuer, setselfpickupuer] = useState(false);
  const [address, setaddress] = useState('');

  useEffect(() => {
    SharedPreferences.getItem('address', address => {
      setaddress(address);
    })
  }, [isFocused])

  return(
    <TouchableOpacity onPress={()=>navigation.navigate('LocationSettings', {logged : 1})} style={[styles.addressbar]}>
        <View>
            <View style={{alignSelf :'center'}}>
                <Text style={[styles.addressbartitle]}>{Languages.DeliveringFood}</Text>
            </View>
            <Text style={[styles.addresstext]} numberOfLines={1}>{address}</Text>
        </View>
    </TouchableOpacity>
  );
}
export default AddressBar;