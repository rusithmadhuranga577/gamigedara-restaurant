import { StyleSheet, Dimensions } from "react-native"
import { Colors, Constants } from '@common';

const width = Dimensions.get('screen').width;
const itemlength = width/6

const styles = StyleSheet.create({
    container : {
        width: '100%', 
        backgroundColor: Colors.backgroundgray,
        justifyContent : 'center',
        alignSelf : 'center',
        padding : 5,
        alignItems : 'center',
        flex : 1
    },
    itemcontainer : {
        width: itemlength, 
        height: itemlength,
        borderRadius : 100,
        alignItems : 'center',
        marginBottom : 18,
        margin : 13
    },
    itemtitlestyle : {
        fontFamily : Constants.fontFamilybold,
        fontSize : 10,
        color : Colors.black,
        marginTop : 3
    },
    image : {
        width: '100%', 
        height: '100%',
        borderRadius : 100,
    },
    gridView: {
        marginTop: 5,
        alignSelf : 'center',
    },
})

export default styles;