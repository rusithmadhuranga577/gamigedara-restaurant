import { StyleSheet } from "react-native"
import { Colors, Constants } from '@common';

const styles = StyleSheet.create({
    container : {
        width: '100%', 
        height: '100%',
        backgroundColor: Colors.white,
    },
    card : {
        height : 130,
        width : '95%',
        alignSelf : 'center',
        backgroundColor : Colors.white,
        elevation : 8,
        borderRadius : 10,
        marginTop : 15,
        marginBottom : 10,
        zIndex : 98
    },
    applybutton : {
        width : 80,
        height : 30,
        borderRadius : 100,
        elevation : 8,
        backgroundColor : Colors.black,
        position : 'absolute',
        bottom : -5,
        right : 25,
        alignItems : 'center',
        justifyContent : 'center',
        zIndex : 99
    },
    applytext : {
        fontFamily : Constants.fontFamilybold,
        color : Colors.white,
        fontSize : 15,
    },
    titlerow : {
        flexDirection : 'row',
        width : '100%',
        alignItems : 'center',
        padding : 5
    },
    title : {
        fontFamily : Constants.fontFamilybold,
        fontSize : 15,
        marginLeft : 15,
        color : Colors.primary
    },
    description : {
        fontFamily : Constants.fontFamilynormal,
        fontSize : 15,
        marginLeft : 5,
        color : Colors.black,
        marginTop : 5
    },
    promocodeholder : {
        padding : 8,
        backgroundColor : Colors.primary,
        alignItems : 'center',
        justifyContent : 'center',
        position : 'absolute',
        left : 0,
        bottom : 0,
        borderBottomLeftRadius : 10,
        borderTopRightRadius : 10
    },
    promocode : {
        fontSize : 10,
        fontFamily : Constants.fontFamilybold,
        color : Colors.white
    }
})

export default styles;