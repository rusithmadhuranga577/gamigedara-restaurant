/** @format */

import React, { useEffect, useState } from 'react';
import {
  TouchableOpacity,
  FlatList,
  Text,
  Dimensions,
  View,
} from 'react-native';
import AsyncStorage from '@react-native-community/async-storage';
import { useNavigation } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/MaterialCommunityIcons';
import styles from './styles';
import { LoadingComponent, CustomAlert, CustomAlertButton } from '@components';
import { Languages, Colors, Url } from '@common';
import { showMessage } from "react-native-flash-message";
import axios from 'axios';

const QueryString = require('query-string');
const ScreenHeight = Dimensions.get('window').height;
const ScreenWidth = Dimensions.get('window').width;

const Promotion =() => {

  const navigation = useNavigation();
  const [appliedpromoid, setappliedpromoid] = useState('');
  const [loading, setloading] = useState(true);
  const [alreadyapplied, setalreadyapplied] = useState(false);
  const [clickedpromo, setclickedpromo] = useState([]);
  const [promolist, setpromolist] = useState([]);

  useEffect(() => {
    axios.post(Url.getalloffersurl, 
      QueryString.stringify({  
      }),
      {
          headers: {"Content-Type": "application/x-www-form-urlencoded",}
      })
      .then(response => {
          setpromolist(response.data.offers);
          setloading(false);
          console.log(response.data.offers[0]);
      }).catch(error => {
          console.log(error);
          setloading(false);
    })
    AsyncStorage.getItem('appliedpromo', (err, promo) => {
      const appliedpromo = JSON.parse(promo)
      if(appliedpromo){
        setappliedpromoid(appliedpromo.id);
      }
    })
  }, []);

  const RemovePromo = () => {
    AsyncStorage.removeItem('appliedpromo');
    setappliedpromoid('');
    showMessage({
      message: "Promotion successfully removed !",
      type: "warning",
      icon : 'warning',
      duration : 2500
    });
    navigation.goBack();
  }

  const ApplyPromoCode = (selectedpromo) => {
    AsyncStorage.getItem('appliedpromo', (err, promo) => {
      if(!promo){
        setappliedpromoid(selectedpromo.id);
        const promoforapply = JSON.stringify(selectedpromo);
        AsyncStorage.setItem('appliedpromo', promoforapply);
        showMessage({
          message: "Promotion successfully added !",
          type: "success",
          icon : 'success',
          duration : 2500
        });
        navigation.goBack();
      }else{
        setclickedpromo(selectedpromo);
        setalreadyapplied(true);
      }
    })
  }

  const RemoveAndApply = () => {
    AsyncStorage.removeItem('appliedpromo');
    setappliedpromoid('');
    console.log(clickedpromo);
    const promoforapply = JSON.stringify(clickedpromo);
    AsyncStorage.setItem('appliedpromo', promoforapply);
    setappliedpromoid(clickedpromo.id);
    setalreadyapplied(false);
    showMessage({
      message: "Promotion successfully added !",
      type: "success",
      icon : 'success',
      duration : 2500
    });
    navigation.goBack();
  }

  const RenderItem = (item) => {
    return(
      <View style={{marginBottom : 22}}>
        <View style={[styles.card, {backgroundColor : appliedpromoid == item.id ? Colors.gray : Colors.white}]}>
          <View style={[styles.titlerow]}>
              <Icon 
              name={
                item.promo_type == 'deliveryfree' ? 'moped' : null ||
                item.promo_type == 'percentage' ? 'percent-outline' : null ||
                item.promo_type == 'valuediscount' ? 'ticket-percent-outline' : null
              } 
              size={23}/>
              <Text style={[styles.title]}>{item.title}</Text>
          </View>
          <View style={[styles.promocodeholder]}>
            <Text style={[styles.promocode]}>{item.promo_code}</Text>
          </View>
          <View>
            <Text style={[styles.description]} numberOfLines={2}>{item.description}</Text>
          </View>
        </View>
        <TouchableOpacity onPress={()=> appliedpromoid == item.id ? RemovePromo() : ApplyPromoCode(item)} style={[styles.applybutton, {backgroundColor : appliedpromoid == item.id ? Colors.alertred : Colors.black}]}>
          <Text style={[styles.applytext]}>{appliedpromoid == item.id ? Languages.Remove : Languages.Apply}</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return(
    <View style={[styles.container]}>
      <LoadingComponent visibility={loading}/>
      <FlatList
        fixed
        spacing={5}
        data={promolist}
        keyExtractor={item => item.id}
        renderItem={({ item }) => RenderItem(item)}
      />
      <CustomAlert
          displayMode={'alert'}
          displayMsg={Languages.YouHaveAlreadyApplied}
          displaymsgtitle={Languages.Alert}
          visibility={alreadyapplied}
          dismissAlert={setalreadyapplied}
          cancellable={true}
          buttons={(
            <>
              <CustomAlertButton buttontitle={Languages.Yes} theme={'alert'} buttonaction={RemoveAndApply}/>
              <CustomAlertButton buttontitle={Languages.No} theme={'inverse'} buttonaction={()=>setalreadyapplied(false)}/>
            </>
          )}
      />
    </View>
  );
}
export default Promotion;