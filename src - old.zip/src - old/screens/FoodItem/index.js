import React, { useEffect, useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
} from 'react-native';
import AsyncStorage from '@react-native-community/async-storage';
import ReactNativeParallaxHeader from 'react-native-parallax-header';
import Icon from 'react-native-vector-icons/FontAwesome5';
import Counter from "react-native-counters";
import { Colors, Constants, Languages } from '@common';
import { useNavigation } from '@react-navigation/native';
import { RadioButton, CartButton } from '@components';
import styles from './styles';
import CheckBox from '@react-native-community/checkbox';
import SetCartPrice from './Addtocart/setcartprice';
import SetCartQty from './Addtocart/setcartqty';
import AddItemsToCart from './Addtocart/additemstocart';
import { showMessage, hideMessage } from "react-native-flash-message";

const App = ({route}) => {

    const navigation = useNavigation();

    const { restaurant_id } = route.params;
    const { restaurantdata } = route.params;
    const { image } = route.params;
    const { name } = route.params;
    const { price } = route.params;
    const { id } = route.params;
    const { foodtypes } = route.params;
    const { addons } = route.params;
    const { secondline } = route.params;

    const [addonslist, setaddonslist] = useState([]);

    const [addonsarray, setaddonsarray] = useState([]);
    const [addsontotal, setaddsontotal] = useState(0);
    const [cartItems, setItemVal] = useState(Number(0));
    const [qty, setQty] = useState(Number(1));
    const [selctedype, setType] = useState(0);
    const [selctedypeName, setTypeName] = useState(0);
    const [selctedypePrice, setTypePrice] = useState(0);
    const [preparationNote, setpreparationNote]= useState('');
    const [total, settotal] = useState(0);

    const types = [];

    for( i=0; i < foodtypes.length; i++){
        types.push({typeid: foodtypes[i].id, lableName: foodtypes[i].type_name, label:  foodtypes[i].type_name, price: foodtypes[i].type_price} );
    }

    useEffect(()=>{
      if(addons != null){
        setaddonslist(addons);
      }
      setType(types[0].food_item_type_id);
      console.log('restaurantdata', restaurantdata);
    },[])

    const gettotal = ({typeprice, addontotal, qty}) => {
        const tp = Number(typeprice);
        const ap = Number(addontotal);
        var total = 0;
        total = (tp + ap)*qty
        const finaltotal = Number(total)
        settotal(finaltotal)
        return finaltotal;
    }

    const addonlist = (index) => {
      const foods = addonslist;
      foods[index].checked = !foods[index].checked;
      var items = addonslist;
      var itemcount = addonslist.length;
      var selectedlist = [];
      var pricelist = [];
      var arraytotal = 0;
  
      for (let i = 0; i < itemcount; i++){
        if(addonslist[i].checked == true){
          selectedlist.push({id :  (Number(addonslist[i].food_item_addon_id)), name: addonslist[i].addon_name, price: addonslist[i].addon_price, qty: qty });
          pricelist.push(Number(addonslist[i].addon_price));
        }
      }
      var newlist = [];
      newlist.push(id,selectedlist)
      setaddonsarray(selectedlist);
      for (let i = 0; i < pricelist.length; i++){ arraytotal += pricelist[i] }
      setaddsontotal(Number(arraytotal));
      gettotal({typeprice : selctedypePrice, addontotal : arraytotal, qty : qty})
    }

    const SetSelectedType = (type_data) => {
        setType(type_data.typeid)
        setTypePrice(type_data.price)
        setTypeName(type_data.lableName)
        gettotal({typeprice : type_data.price, addontotal : addsontotal, qty : qty})
    }

    const OnQtyChange = ({number}) => {
        const q = number;
        setQty(q);
        setItemVal(q);
        gettotal({typeprice : selctedypePrice, addontotal : addsontotal, qty : q})
    }

    const AddToCart = () => {
      const itemsArray = [
        {
            food_item_type_id : selctedype,
            restaurant_id : restaurant_id,
            restaurant_name : restaurantdata.name,
            item_name : name,
            item_image : image,
            food_items_id : id,
            item_type_id : selctedype,
            item_type_name : selctedypeName,
            item_type_price: Number(selctedypePrice) ,
            item_total: (Number(total)),
            item_addon_price: Number(addsontotal),
            item_qty : qty,
            item_prepare_note: preparationNote,
            addons : addonsarray,
        }
      ]
      AsyncStorage.setItem('cart_merchant_type', restaurantdata.restaurant_type);
      AddItemsToCart(itemsArray);
      SetCartPrice(total);
      SetCartQty(qty);
      showMessage({
        message: "Item added to cart !",
        type: "success",
        icon : 'success',
        duration : 2500
      });
      setTimeout(() => {
        navigation.goBack();
      }, 500);
    }

    const renderNavBar = () => (
        <View style={styles.navContainer}>
          <View style={styles.navBar}>
            <TouchableOpacity onPress={()=>navigation.goBack()} style={styles.iconLeft}>
              <Icon name={'chevron-left'} size={20} color={Colors.white}/>
            </TouchableOpacity>
            <TouchableOpacity style={styles.iconRight} onPress={() => {}}>
              <Icon name={'search'} size={20} color={Colors.white}/>
            </TouchableOpacity>
          </View>
        </View>
      );
      
      const TitleHolder = ({title}) => {
        return (
            <View style={[styles.titleholder]}>
                <Text style={[styles.titleholdertext]}>{title}</Text>
            </View>
        );
      };

      const renderContent = () => {
        return (
            <View style={styles.body}>
                <Text style={[styles.secondlinestyle]} numberOfLines={3}>{secondline}</Text>
                <TitleHolder title={Languages.Select}></TitleHolder>
                <RadioButton
                    data={types}
                    initial={1}
                    box = {false}
                    selectedBtn={(e) => {SetSelectedType(e)}}            
                    animationTypes= {['pulse', 'shake', 'rotate']}
                />

                <TitleHolder title={Languages.Addons}></TitleHolder>
                {addonslist.map((addon, index ) => {
                  return (
                      <View style={[styles.addonitemrow]}>
                        <View style={[styles.addonrowleftitem]}>
                        <CheckBox
                            center
                            boxType = {'circle'}
                            title={addon.addon_name}
                            tintColors = {Colors.primary}
                            iconRight
                            onValueChange={() => addonlist(index)}
                            value={addon?.checked}
                            size={30}
                        />
                        <Text>{addon.addon_name}</Text>
                        </View>
                        <Text>{addon.addon_price == 0 ? null : '+ '+'Rs.'+Number(addon.addon_price).toFixed(2)}</Text>
                    </View>
                  )
                })}

                <TextInput 
                  value={preparationNote}
                  placeholder={Languages.PreparationNote}
                  onChangeText={text => setpreparationNote(text)}
                  style={[styles.textinput]}
                  placeholderTextColor={'rgba(0,0,0,0.4)'}
                />
                <View style={{marginTop: 20, marginBottom: 20, alignItems: 'center'}}>
                    <Counter 
                        start={1}
                        min	={1}
                        buttonStyle ={styles.counterbtn}
                        buttonTextStyle = {styles.counterbuttontextstyle}
                        countTextStyle = {styles.countertext}
                        onChange={(count)=> OnQtyChange({number : count})} />
                </View>
                <View style={{padding : 10}}>
                    <CartButton total={total} action={AddToCart}/>
                </View>
            </View>
        );
      };
      
      const title = () => {
        return (
          <View style={styles.imageoverlay}>
              <Text style={[styles.titlestyle]}>{name}</Text>
          </View>
        );
      };      

  return (
    <>
      <ReactNativeParallaxHeader
        headerMinHeight={styles.HEADER_HEIGHT}
        headerMaxHeight={250}
        extraScrollHeight={20}
        navbarColor={Colors.black}
        titleStyle={styles.titleStyle}
        title={title()}
        backgroundImage={{uri : image}}
        backgroundImageScale={1.5}
        renderNavBar={renderNavBar}
        renderContent={()=>renderContent()}
        containerStyle={styles.container}
        contentContainerStyle={styles.contentContainer}
        innerContainerStyle={styles.container}
      />
    </>
  );
};

export default App;