import { StyleSheet, View, Text, Image, ScrollView, Component, FlatList} from 'react-native';
import React , { useState, useEffect } from 'react';
import { Images, Languages, Colors, Constans, Url } from '@common';
import { LoadingComponent } from '@components';
import { useIsFocused } from '@react-navigation/native';
import styles from './styles';
import axios from 'axios';

const QueryString = require('query-string');

function Offers(){

    const [loading, setloading] = useState(true);
    const [items, setItems] = useState([]);
    const isFocused = useIsFocused();

    useEffect(() => {
        setloading(true);
        axios.post(Url.getalloffersurl, 
        QueryString.stringify({  
        }),
        {
            headers: {"Content-Type": "application/x-www-form-urlencoded",}
        })
        .then(response => {
            setItems(response.data.offers);
            setloading(false);
        }).catch(error => {
            console.log(error);
            setloading(false);
        })
    }, [isFocused]);

    return(
        <View style={[styles.container]}>
            <LoadingComponent visibility={loading}/>
            <FlatList
                itemDimension={80}
                data={items}
                style={styles.gridView}
                spacing={3}
                renderItem={({ item }) => (
                    <View style={styles.itemcontainer} >
                        <View>
                            <View>
                                <View style={[styles.promocodecontainer]}>
                                    <Text style={[styles.name]} numberOfLines={1}>{item.promo_code}</Text>
                                </View>
                                <Image style={styles.imagecontainer} source={{uri: item.image}}></Image>
                            </View>
                            <View style={{flexDirection: 'column'}}>
                                <View style={{flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center'}}>
                                    <Text style={[styles.secondline, {marginTop : 5}]} numberOfLines={2}>{item.name}</Text>
                                </View>

                                <View style={{flexDirection: 'row', height: 20, alignContent: 'center', justifyContent: 'flex-start', marginTop : 5}}>
                                    <Text style={[styles.validto]} numberOfLines={3}>{Languages.Validtill} {item.valid_to}</Text>
                                </View>
                                <Text numberOfLines={2} style={[styles.description]}>{item.description}</Text>
                            </View>
                        </View>
                    </View>
                )}
            />
        </View>

    );
}

export default Offers;