import { StyleSheet } from "react-native"
import { Colors, Constants } from '@common';

const styles = StyleSheet.create({
    container : {
        width: '100%', 
        height: '100%',
        backgroundColor: '#fff',
    },
    addressbar : {
        width: '100%', 
        height : 60,
        backgroundColor : Colors.white,
        alignItems : 'center',
        justifyContent : 'center',
        elevation : 8,
        paddingTop : 3,
    },
    addressbartitle : {
        fontSize : 13,
        fontFamily : Constants.fontFamilybold,
        alignSelf : 'center',
        color : Colors.primary
    },
    addresstext : {
        fontSize : 12,
        fontFamily : Constants.fontFamilybold,
        marginTop : 5,
        alignSelf : 'center',
    },
    cartpopupcontainer : {
        width : '100%',
        height : 70,
        backgroundColor : Colors.primary,
        borderTopLeftRadius : 8,
        borderTopRightRadius : 8,
        flexDirection : 'row',
        justifyContent : 'space-between',
        position : 'absolute',
        bottom : 50
    },
    cartpricetext : {
        fontSize : 18,
        fontFamily : Constants.fontFamilybold,
        color : Colors.white
    },
    cartqtytext : {
        fontSize : 15,
        fontFamily : Constants.fontFamilynormal,
        color : Colors.white
    },
    cartpopupicon : {
        alignSelf : 'center',
        marginRight : 25
    },
})

export default styles;