import React, { useEffect, useRef } from 'react';
import { connect } from "react-redux";
import {
  SafeAreaView,
  ScrollView,
  Image,
  FlatList,
  Text,
  Dimensions,
  View,
  Animated
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import styles from './styles';

const HorizontalList = ({list}) => {

  useEffect(()=>{
  },[])
  
  return(
      <View style={[styles.container]}>
        <FlatList
          horizontal
          showsHorizontalScrollIndicator={false}
          itemDimension={80}
          data={list}
          style={styles.gridView}
          spacing={3}
          renderItem={({ item }) => (
            <View style={[styles.itemcontainer]} >
              <View style={[styles.imagecontainer]}>
                <Image source={{uri : item.image}} style={[styles.image]}/>
              </View>
              <Text style={[styles.itemtitlestyle]}>{item.name}</Text>
            </View >
          )}
      />
      </View>
  );
}

export default HorizontalList;