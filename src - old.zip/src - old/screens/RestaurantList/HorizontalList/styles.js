import { StyleSheet } from "react-native"
import { Colors, Constants } from '@common';

const styles = StyleSheet.create({
    container : {
        width : '100%',
        padding : 10,
        backgroundColor : Colors.gray
    },
    itemcontainer : {
        width: 60, 
        height: 60,
        borderRadius : 100,
        marginLeft : 10,
        marginRight : 10,
        alignItems : 'center',
        justifyContent : 'center',
        margin : 5
    },
    imagecontainer : {
        width : 50,
        height: 50
    },
    image : {
        width : '100%',
        height : '100%'
    },
    itemtitlestyle : {
        fontFamily : Constants.fontFamilybold,
        fontSize : 12,
        color : Colors.black
    },
})

export default styles;