/** @format */

import React, { useEffect, useState } from 'react';
import {
  Text,
  View,
  TouchableOpacity
} from 'react-native';
import AsyncStorage from '@react-native-community/async-storage';
import { useNavigation } from '@react-navigation/native';
import { useIsFocused } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/Ionicons';
import styles from './styles';
import { Languages } from '@common';

const AddressBar =({height}) => {

  const navigation = useNavigation();
  const isFocused = useIsFocused();
  const [selfpickupuer, setselfpickupuer] = useState(false);
  const [address, setaddress] = useState('');

  useEffect(() => {
    AsyncStorage.getItem('address', (err, address) => {
      setaddress(address);
    });
  }, [])

  return(
    // <TouchableOpacity onPress={()=>navigation.navigate('LocationSettings', {logged : 1})} style={[styles.addressbar]}>
    <TouchableOpacity style={[styles.addressbar]}>
        {selfpickupuer ? 
        <Text style={[styles.addressbartitle]}>{Languages.SelfPickupUser}</Text>
        :
        <View style={{width : '80%'}}>
            <View style={{alignSelf :'center'}}>
                <Text style={[styles.addressbartitle]}>{Languages.DeliveringFood}</Text>
            </View>
            <Text style={[styles.addresstext]} numberOfLines={1}>{address}</Text>
        </View>
        }
    <Icon name={'search-outline'} size={20} style={{position : 'absolute', right : 15}} onPress={()=>navigation.navigate('SearchPage', {title : Languages.Search})}/>
    <Icon name={'chevron-back-outline'} size={20} style={{position : 'absolute', left : 15}} onPress={()=>navigation.goBack()}/>
    </TouchableOpacity>
  );
}
export default AddressBar;