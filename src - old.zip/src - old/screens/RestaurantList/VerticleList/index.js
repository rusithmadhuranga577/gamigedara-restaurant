import React from 'react';
import PropTypes from 'prop-types';
import {
  Image,
  FlatList,
  Text,
  TouchableOpacity,
  View,
  Dimensions,
  Linking
} from 'react-native';
import AsyncStorage from '@react-native-community/async-storage';
import { useNavigation } from '@react-navigation/native';
import { useIsFocused } from '@react-navigation/native';
import { Colors, Languages, Url, Images } from '@common';
import Icon from 'react-native-vector-icons/Ionicons';
import { Clearcartpopup } from '@components';
import { showMessage } from "react-native-flash-message";
import styles from './styles';
import axios from 'axios';

const screenheight = Dimensions.get('screen').height;
const QueryString = require('query-string');

class VerticleList extends React.Component{

  constructor(props) {
    super(props);
    this.state = {
        cartrestaurantid : null,
        loading : false,
        stores : null,
        clearcartpopup : false,
        oldcartdata : [],
        oldcartprice : 0,
        oldcartqty : 0,

        clickedrestaurantid : null,
        clickedrestaurantfoodlist : [],
        clickedrestauranttabs : [],
        clickedrestaurantimage : '',
        clickedrestaurantdata : []
    };
    this.getLoadingstate = this.getLoadingstate.bind(this);
  }

  getLoadingstate(state){
    this.props.getLoadingstate(state);
  }

  getinitialdata(){
    const paramdata = this.props.params;
    axios.post(Url.restaurantlisturl, 
      QueryString.stringify({
          filter : paramdata.filter,
          type : paramdata.type,
          count : 100,
          lat : paramdata.lat,
          lon : paramdata.lon,
          savedcartdata : []
      }), 
      {
          headers: {"Content-Type": "application/x-www-form-urlencoded",}
      }).then(response => {
          if(response.data.data.length == 0){
            this.setState({stores : 'empty'});
          }else{
            this.setState({stores : response.data.data});
            console.log(response.data.data[0])
          }
      })
    AsyncStorage.getItem('cartrestaurantid', (err, id)=>{
      if(id != null){
        this.setState({cartrestaurantid : id})
        AsyncStorage.getItem('cartitems', (err, cartitems)=>{
          const cartitemsdata = JSON.parse(cartitems);
          console.log('cart items', cartitemsdata)
          if(cartitemsdata != null){
            this.setState({oldcartdata : cartitemsdata});
          }            
        });
        AsyncStorage.getItem('cartprice', (err, oldcartprice) => {
          this.setState({oldcartprice : oldcartprice});
        });
        AsyncStorage.getItem('cartqty', (err, oldcartqty) => {
          this.setState({oldcartqty : oldcartqty});
        });
      }else{
        this.setState({cartrestaurantid : 'no_cart_restaurant'})
      }
    });
  }

  componentDidMount(){
    this.unsubscribe = this.props.navigation.addListener('focus', () => {
      this.getinitialdata();
    });
    this.getinitialdata();
  }

  NavigateFunction(item){
    
    const res_id = item.id;
    const res_id_state = this.state.cartrestaurantid;
    if(res_id_state != 'no_cart_restaurant'){
      if(res_id != res_id_state){
        this.setState({clickedrestaurantid : res_id});
        this.OpenClearCartPopup();
      }else{
        this.props.navigation.push('MenuList', {resid : res_id, restaurantdata : item});
      }
    }else{
      this.props.navigation.push('MenuList', {resid : res_id, restaurantdata : item});
    }
    // this.props.navigation.push('MenuList', {itemid : this.state.clickedrestaurantid, restaurantdata : item});
    this.getLoadingstate(false);
  }

  ClearCartAndNavigate=()=>{
    this.props.navigation.push('MenuList', {resid : this.state.clickedrestaurantid, restaurantdata : this.state.clickedrestaurantdata});
  }

  SaveCartFunction=()=>{
    var date = new Date().getDate();
    var month = new Date().getMonth() + 1;
    var year = new Date().getFullYear();
    var hours = new Date().getHours();
    var min = new Date().getMinutes();
    var sec = new Date().getSeconds();

    var RandomNumber = Math.floor(Math.random() * 100) + 1 ;
    var randomid = hours+min+sec+RandomNumber;
    var created_time = `${year}-${month}-${date} ${hours}:${min}`;

    var cartarray = [];
    const savedcartdata = this.state.oldcartdata;
    const oldcartprice = this.state.oldcartprice;
    cartarray.push({'id' : randomid,'cartprice' : oldcartprice, 'cartitems' : savedcartdata, 'saved' : created_time, 'cartqty' : this.state.oldcartqty});
    
    AsyncStorage.getItem('savedcartitems', (err, oldsavedcartitems) => {
      if (oldsavedcartitems == null) {
        AsyncStorage.setItem('savedcartitems', JSON.stringify(cartarray));
        console.log('cart array',cartarray);
        this.ClearCartFunction();
      } else {
        const concactedObject = JSON.parse(oldsavedcartitems).concat(cartarray);
        AsyncStorage.setItem('savedcartitems', JSON.stringify(concactedObject));
        console.log(concactedObject);
        this.ClearCartFunction();
      }
    })
  }

  TemporyClear=()=>{
    AsyncStorage.removeItem('savedcartitems');
    this.CloseClearCartPopup();
  }

  ClearCartFunction=()=>{
    AsyncStorage.removeItem('cartitems');
    AsyncStorage.removeItem('cartprice');
    AsyncStorage.removeItem('cartqty');
    AsyncStorage.removeItem('cartrestaurantid');
    this.setState({clearcartpopup : false});
    this.setState({cartrestaurantid : 'no_cart_restaurant'});
    this.ClearCartAndNavigate();
  }

  OpenClearCartPopup=()=>{
    this.setState({clearcartpopup : true});
  }

  CloseClearCartPopup=()=>{
    this.setState({clearcartpopup : false});
  }

  OpenMapsFunction = (lat, lan) => {
    const scheme = Platform.select({ ios: 'maps:0,0?q=', android: 'geo:0,0?q=' });
    const latLng = `${lat},${lan}`;
    const label = 'Custom Label';
    const url = Platform.select({
      ios: `${scheme}${label}@${latLng}`,
      android: `${scheme}${latLng}(${label})`
    });
    Linking.openURL(url);
  }

  ShowShopCloasedAlert = (name) => {
    showMessage({
        message: `Sorry ${name} is closed now`,
        type: "warning",
        icon : 'warning',
        duration : 3000
    });
  }

  render(){
    return(
      <View style={[styles.container, {backgroundColor : '#fff'}]}>
      {this.state.stores == 'empty' ? 
      <View style={[styles.emptycontainer]}>
        <Image source={Images.storelistempty} style={{width : '100%', height : '45%', opacity : 0.5}}/>
        <Text numberOfLines={1} style={[styles.unabletofindtext]}>{Languages.UnableToFindStoresNearYou}</Text>
      </View>
      :
        <View style={[styles.container]}>
          <FlatList
            showsHorizontalScrollIndicator={false}
            data={this.state.stores}
            itemDimension={80}
            spacing={3}
            style={{marginBottom : 120}}
            renderItem={({ item }) => (
              <TouchableOpacity onPress={()=>item.open == 0 ? this.ShowShopCloasedAlert(item.name) : this.NavigateFunction(item)} style={[styles.itemcontainer]} >
                <Image source={{uri : item.cover_banner}} style={[styles.image]}/>
                <Text style={[styles.name]} numberOfLines={2}>{item.name}</Text>
                <Text style={[styles.address]} numberOfLines={2}>{item.address_line_1}, {item.address_line_2}</Text>
                <TouchableOpacity onPress={()=>Linking.openURL(`tel:${item.hotline}`)} style={{flexDirection : 'row', alignItems : 'center', marginTop : 10, position : 'absolute', bottom : 10, left : 10}}>
                  <Icon name={'call'} size={15}/>
                  <Text style={[styles.phone]} numberOfLines={2}>{item.hotline}</Text>
                </TouchableOpacity>
                <TouchableOpacity onPress={()=>this.OpenMapsFunction(item.map_latitude, item.map_longitude)} style={[styles.directionimage]}>
                  <Image source={Images.Direction} style={{width : '100%', height : '100%'}}/>
                </TouchableOpacity>
                <View style={[styles.openclosecontainer, {backgroundColor : item.open == 0 ? Colors.alertred : Colors.successgreen}]}>
                  <Text style={[styles.openclosetext]} numberOfLines={2}>{item.open == 0 ? Languages.Close : Languages.Open}</Text>
                </View>
              </TouchableOpacity>
            )}
        />
        </View>}
      {this.state.clearcartpopup ? 
        <View style={{width : '100%', height : screenheight, position : 'absolute', zIndex : 150, bottom : 0}}>
          <Clearcartpopup StartNew={()=>this.SaveCartFunction()} Cancel={()=>this.CloseClearCartPopup()} visibility={this.state.clearcartpopup} />
        </View>:null}
      </View>
    );
  }
}

VerticleList.propTypes = {
  getLoadingstate: PropTypes.func,
};

export default function(props){
  const isFocused = useIsFocused();
  const navigation = useNavigation();
  return <VerticleList {...props} navigation={navigation} isFocused={isFocused}/>;
} 