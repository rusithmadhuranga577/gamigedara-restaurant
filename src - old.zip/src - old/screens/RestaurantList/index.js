import React, { useEffect, useState, useRef } from 'react';
import {
  SafeAreaView,
  ScrollView,
  Text,
  TouchableOpacity,
  View,
  Animated,
  Dimensions
} from 'react-native';
import AsyncStorage from '@react-native-community/async-storage';
import { useNavigation } from '@react-navigation/native';
import { useIsFocused } from '@react-navigation/native';
import styles from './styles';
import AddressBar from './addressbar';
import VerticleList from './VerticleList';
import { LoadingComponent } from '@components';
import Icon from 'react-native-vector-icons/Ionicons';
import { Colors, Languages } from '@common';

const RestaurantList = ({route}) => {
    const { dummydata } = route.params
    const isFocused = useIsFocused();
    const navigation = useNavigation();
    const [loading, setloading] = useState(false);
    const [cartitems, setcartitems] = useState([]);
    const popupanimation = useRef(new Animated.Value(0)).current;
    const [cartprice, setcartprice] = useState(0);
    const [cartqty, setcartqty] = useState(0);

    useEffect(()=>{
        Getcartdata();
    }, [isFocused])

    const animatein = () => {
        Animated.timing(popupanimation, {
          toValue: 70,
          duration: 500
        }).start();
      };
    
    const animateout = () => {
    Animated.timing(popupanimation, {
        toValue: 0,
        duration: 600
    }).start();
    };

    const NavigateToCartPage = () => {
        navigation.push('CartPage')
    }

    const Getcartdata = () => {
    AsyncStorage.multiGet(['cartprice', 'cartqty', 'cartrestaurantid'], (err, cartdata) =>{
        if(cartdata[0][1] == null && cartdata[1][1] == null){
            animateout();
        }else{
            animatein();
            setcartitems(cartdata);
            setcartprice(cartdata[0][1]);
            setcartqty(cartdata[1][1]);
        }
    });
    }

    const CartPopup = () => {
        return(
          <TouchableOpacity onPress={NavigateToCartPage}>
              <Animated.View style={[styles.cartpopupcontainer, {height : popupanimation}]}>
                <View style={{alignSelf : 'center', marginLeft : 25}}>
                  <Text style={[styles.cartpricetext]}>{Languages.Rs}{Number(cartprice).toFixed(2)}</Text>
                  <Text style={[styles.cartqtytext]}>{cartqty} {Languages.ItemsinCart}</Text>
                </View>
                <Icon name={'cart'} size={35} style={[styles.cartpopupicon]} color={Colors.white}/>
              </Animated.View>
          </TouchableOpacity>
        );
      }

    return(
        <SafeAreaView style={[styles.container, {height : Dimensions.get('screen').height}]}>
            <LoadingComponent visibility={loading}/>
            <AddressBar/>
            <VerticleList getLoadingstate={(state)=>setloading(state)} params={route.params} dummydata={dummydata}/>
            <CartPopup/>
        </SafeAreaView>
    );
}

export default RestaurantList;