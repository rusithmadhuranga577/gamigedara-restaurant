/** @format */

import React, { useEffect, useState, useRef } from 'react';
import {
  SafeAreaView,
  Image,
  Text,
  Animated,
  View,
  TouchableOpacity,
  Dimensions,
  ImageBackground,
} from 'react-native';
import AsyncStorage from '@react-native-community/async-storage';
import SectionList from 'react-native-tabs-section-list';
import { useNavigation } from '@react-navigation/native';
import { Colors, Url, Languages } from '@common';
import { LoadingComponent } from '@components';
import { useIsFocused } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/Ionicons';
import axios from 'axios';
import NavBar from './navbar';
import styles from './styles';

const QueryString = require('query-string');
const screenwidth = Dimensions.get('window').width;

const MenuList =({route}) => {
  const { resid } = route.params;
  const { restaurantdata } = route.params;
  const popupanimation = useRef(new Animated.Value(0)).current;
  const navigation = useNavigation();
  const isFocused = useIsFocused();

  const sectionListRef = useRef(null);
  const tabbarRef = useRef(null);
  const [menulist, setmenulist] = useState([]);

  const [loading, setloading] = useState(false);
  const [hasScrolled, sethasScrolled] = useState(false);
  const [cartdata, setcartdata] = useState(false);
  const [cartitems, setcartitems] = useState([]);
  const [cartprice, setcartprice] = useState(0);
  const [cartqty, setcartqty] = useState(0);

  const shop = [{'shop_name' : 'Gamigedara'}]

  const ITEM_HEIGHT = 100;

  useEffect(()=>{
    console.log('LENGTH',restaurantdata.restaurant_type);
    Getcartdata();
    FetchMenuList();
  }, [isFocused])

  const FetchMenuList=()=>{
    setloading(true);
    axios.post(Url.menulisturl, 
    QueryString.stringify({
      restaurant_id : resid,
    }), 
    {
        headers: {"Content-Type": "application/x-www-form-urlencoded",}
    }).then(response => {
      console.log(response.data, resid);
      setmenulist(response.data);
      setloading(false);
    })
  }

  const animatein = () => {
    Animated.timing(popupanimation, {
      toValue: 70,
      duration: 500
    }).start();
  };

  const animateout = () => {
    Animated.timing(popupanimation, {
      toValue: 0,
      duration: 600
    }).start();
  };

  const NavigateToCartPage = () => {
    AsyncStorage.getItem('cart_merchant_type', (err, type) => {
      if(type != 'fashion'){
          navigation.push('CartPage');
      }else{
          navigation.push('FashionItemsCart');
      }
    });
  }

  const Getcartdata = () => {
    AsyncStorage.multiGet(['cartprice', 'cartqty', 'cartrestaurantid'], (err, cartdata) =>{
      if(cartdata[0][1] == null && cartdata[1][1] == null){
        animateout();
      }else{
        animatein();
        setcartprice(cartdata[0][1]);
        setcartqty(cartdata[1][1]);
      }
    });
  }

  const nav = (item) => {
    console.log(item.foodtype)
    navigation.push('FoodItem' , {name: item.food_name, price: item.price, image: item.image_large, id: item.id , foodtypes : item.foodtype, secondline: item.second_line,  addons: item.addons.length == 0? null : item.addons[0].addonitems, restaurant_id : restaurantdata.id, restaurantdata : restaurantdata });
  }

  var i = 0;
  const RenderItem = (item) => {
    return(
      <>
        {item.id != 0 ?
        <View style={{flexDirection : 'column'}}>
        <TouchableOpacity onPress={()=>item.available == 0 ? null : nav(item)} style={[styles.itemcontainer, {opacity : item.available == 0  || item.available == 2 ? 0.5 : 1}]}>
          <View style={{width : '70%'}}>
              <Text numberOfLines={1} style={[styles.foodname]}>{item.food_name}</Text>
              {item.second_line == '' ? null : <Text numberOfLines={2} style={[styles.foodsecondline]}>{item.second_line}</Text>}
            <View>
              <Text style={[styles.price]}>{Languages.Rs}{Number(item.price).toFixed(2)}</Text>
            </View>
            {/* {item.popularitem == 0 ? null : <View style={[styles.populerbadge]}><Text style={[styles.populerbadgetext]}>Populer</Text></View>} */}
          </View>                    
          <View>
              {item.image_thumb == null ? null : <Image style={styles.image} source={{uri: item.image_thumb}} ></Image>}      
          </View>
        </TouchableOpacity>
        {item.available == 0 ?
        <View style={[styles.itemoverlay]}>
          <Text style={[styles.notavailabletext]}>{Languages.ItemNotAvailable}</Text>
        </View>
        :null}
        {item.available == 2 ?
        <View style={[styles.itemoverlay]}>
          <Text style={[styles.notavailabletext]}>{Languages.ItemNotAvailableUntilTomorrow}</Text>
        </View>
        :null}
        </View> : 
        <View style={{height : 200, width: '100%', backgroundColor : 'black'}}>
          <ImageBackground style={{width: '100%', height : '100%'}} source={{uri : item.cover_banner}}>
            <View style={[styles.res_banner_overlay]}>
              <Text style={[styles.restaurantname]}>{item.name}</Text>
              <View style={{width : '100%', flexDirection : 'row', alignItems : 'center'}}>
                <Icon name={'star'} style={{paddingRight : 5}} size={12} color={Colors.alertyellow}/>
                <Text style={[styles.restaurandeliverytime]}>({item.def_rating_count})</Text>
                <Text style={[styles.restaurandeliverytime]}>   | </Text>
                <Icon name={'bicycle-outline'} style={{paddingRight : 10, paddingLeft : 10}} size={18} color={Colors.white}/>
                <Text style={[styles.restaurandeliverytime]}>{Languages.Within} {item.delivery_time} {Languages.Minutes}</Text>
                <Text style={[styles.restaurandeliverytime]}>   |   </Text>
                <Icon name={'time-outline'} style={{paddingRight : 5}} size={12} color={Colors.white}/>
                <Text style={[styles.restaurandeliverytime]}>{Number(item.open_time).toFixed(2)} - {Number(item.close_time).toFixed(2)}</Text>
              </View>
              <View style={{width : '100%', flexDirection : 'row', alignItems : 'center'}}>
                
              </View>
            </View>
          </ImageBackground>

        </View>
        }
      </>
    );
  }

  const HeaderItem = (section) => {
    return(
      <>
      {section.index == 0 ? null : 
      <View style={styles.headercontainer}>
        <Text style={[styles.headertitle]}>{section.title}</Text>
      </View>}
      </>
    );
  }

  const CartPopup = () => {
    return(
      <TouchableOpacity onPress={NavigateToCartPage}>
          <Animated.View style={[styles.cartpopupcontainer, {height : popupanimation, bottom : 30}]}>
            <View style={{alignSelf : 'center', marginLeft : 25}}>
              <Text style={[styles.cartpricetext]}>{Languages.Rs}{Number(cartprice).toFixed(2)}</Text>
              <Text style={[styles.cartqtytext]}>{cartqty} {Languages.ItemsinCart}</Text>
            </View>
            <Icon name={'cart'} size={35} style={[styles.cartpopupicon]} color={Colors.white}/>
          </Animated.View>
      </TouchableOpacity>
    );
  }

  const TabItem = (title, isActive) => {
    return(
      <View style={[styles.tabbarcontainer, {backgroundColor : isActive ? Colors.primary : Colors.white, marginTop : 20}]}>
        {restaurantdata.restaurant_type == 'fashion' ? 
        <View style={[styles.tabcontainer]}>
          {title == 'Overview' ? 
          <Icon name={'shirt-outline'} size={20} color={isActive ? Colors.white : Colors.black}/> 
          :
          <Text style={[styles.tabbartitle, {color : isActive ? Colors.white : Colors.black}]}>
              {title}
          </Text>}
        </View>
        :
        <View style={[styles.tabcontainer]}>
          {title == 'Overview' ? 
          <Icon name={'fast-food'} size={20} color={isActive ? Colors.white : Colors.black}/> 
          :
          <Text style={[styles.tabbartitle, {color : isActive ? Colors.white : Colors.black}]}>
              {title}
          </Text>}
        </View>}
      </View>
    );
  }

  const MainView = () => {
    return(
      <View style={{width : '100%', height : '100%', backgroundColor : '#fff'}}>
      <LoadingComponent visibility={loading}/>
      {menulist.length == 0 ? null :
        <SectionList
          sections={menulist}
          keyExtractor={item => item.id}
          stickySectionHeadersEnabled={false}
          scrollToLocationOffset={50}
          tabBarStyle={styles.tabBar}
          renderSectionHeader={({ section}) => HeaderItem(section)}
          ItemSeparatorComponent={() => <View style={styles.separator} />}
          renderTab={({ title, isActive }) => TabItem(title, isActive)}
          renderItem={({ item}) => RenderItem(item)}
        />}
      </View>
    );
  }

  return (
    <SafeAreaView style={{width : '100%', height : Dimensions.get('screen').height, backgroundColor : '#fff'}}>
      <NavBar title={restaurantdata.name}/>
      {MainView()}
      <CartPopup/>
    </SafeAreaView>
  );
}

export default MenuList;