/** @format */

import React, { useEffect } from 'react';
import {
  ScrollView,
  Image,
  Text,
  Dimensions,
  View,
  TouchableOpacity
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import styles from './styles';
import GoogleLogin from './SocialLogin/googlelogin';
// import FacebookLogin from './SocialLogin/facebooklogin';
import { Images, Languages, Colors } from '@common';

const screenHeight = Dimensions.get('screen').height;

const Login =() => {

  const navigation = useNavigation();

  useEffect(() => {
  }, [])

  const ButtonView = ({icon, title, actiontype, navpage}) => {
      return(
        <TouchableOpacity 
          onPress={()=>actiontype == 'nav' ? navigation.push(navpage):null} 
          style={[styles.button]}
        >
          <Image source={icon} style={[styles.bottonimage]}></Image>
          <Text style={[styles.buttontitle]}>{title}</Text>
        </TouchableOpacity>
      );
  }

  return(
    <View style={[styles.container, {padding: 0, backgroundColor : Colors.primary}]}>
        <ScrollView style={[styles.bottomcard]}>
            <Text style={[styles.title]}>{Languages.loginCardTitle}</Text>
            <Text style={[styles.subtitle]}>{Languages.loginCardSubtitle}</Text>
            <View style={[styles.buttoncontainer]}>
                <GoogleLogin/>
                {/* <FacebookLogin/> */}
                <ButtonView icon={Images.PhoneIcon} title={Languages.phonenumberbuttontitle} actiontype={'nav'} navpage={'PhoneInput'}/>
                <ButtonView icon={Images.UsernamePassword} title={Languages.LoginwithUserNamePassword} actiontype={'nav'} navpage={'UsernamepassowrdLogin'}/>
            </View>
        </ScrollView>
        <Image source={Images.Logo} style={[styles.logoimage]}/>
    </View>
  );
}
export default Login;