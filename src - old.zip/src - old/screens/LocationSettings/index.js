/** @format */

import React, { useEffect, useState, useRef  } from 'react';
import {
  ScrollView,
  FlatList,
  Text,
  View,
  TouchableOpacity,
  Animated,
  LogBox
} from 'react-native';
import AsyncStorage from '@react-native-community/async-storage';
import { useNavigation } from '@react-navigation/native';
import { useIsFocused } from '@react-navigation/native';
import styles from './styles';
import { Languages, Colors, Url } from '@common';
import { LoadingComponent, CustomAlert, CustomAlertButton } from '@components';
import Icon from 'react-native-vector-icons/FontAwesome5';
import Geolocation from '@react-native-community/geolocation';
import DeviceSettings from 'react-native-device-settings';
import { showMessage } from "react-native-flash-message";
import axios from 'axios';

const QueryString = require('query-string');

const LocationSettings =({route}) => {
  const {logged} = route.params;
  const navigation = useNavigation();
  const isFocused = useIsFocused();

  const [loading, setloading] = useState(false);
  const [selfpickupalert, setselfpickupalert] = useState(false);
  const [locationrequesttimeout, setlocationrequesttimeout] = useState(false);
  const [deliveryarealist, setdeliveryarealist] = useState([]);
  const [recentLocations, setrecentLocations] = useState([]);

  const animatein = useRef(new Animated.Value(0)).current;

  useEffect(() => {
    AsyncStorage.getItem('userlocation', (err, type)=>{
      console.log(type);
    });
    
    LogBox.ignoreAllLogs();
    setloading(true);
    fetch(Url.deliveryareaurl)
    .then((response) => response.json())
    .then((data) => {
      console.log(data.data)
      setdeliveryarealist(data.data);
      setloading(false);
    })
    AsyncStorage.getItem('recentlocations', (err, data)=>{
      console.log('recentlocations', JSON.parse(data));
      setrecentLocations(JSON.parse(data));
    });
  }, [isFocused])

  const alertin = () => {
    Animated.timing(animatein, {
      toValue: 100,
      duration: 1000
    }).start();
  };

  const alertout = () => {
    Animated.timing(animatein, {
      toValue: 0,
      duration: 1000
    }).start();
  };

  const GetLocation = () => {
    alertout();
    Geolocation.getCurrentPosition(
      position => {
      },
      error => {
        alertin();
      },
      {
        showLocationDialog: true,
        enableHighAccuracy: true,
        timeout: 50000,
        maximumAge: 0,
      },
    );
  }

  const SelfpickupUser = () => {
    AsyncStorage.setItem('userlocation', "outofdeliveryrange");
    setselfpickupalert(false);
    if(logged == 0){
      navigation.replace('HomeTabNavigator');
    }else{
      navigation.goBack();
    }
  }

  const UpdateLocation = (item) => {
    setloading(true);
    const data = item;
    const addressArray = [{
      location: data.location,
      id: data.id,
      address: data.address,
      latitude: data.latitude,
      longitude: data.longitude
    }]

    AsyncStorage.getItem('userid', ((err, uId) => {
      console.log(addressArray)
      const id = uId;
      axios.put(Url.updateuseraddress+id,
        QueryString.stringify({
          location_type: data.location,
          def_address: data.address,
          def_lat: data.latitude,
          def_lon: data.longitude
        }),
        {
          headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        },
      ).then(response => {
          if (response.data.status == 1) { 
            AsyncStorage.setItem('address', data.address);
            AsyncStorage.setItem('latitude', data.latitude+'');
            AsyncStorage.setItem('longitude', data.longitude+'');
            AsyncStorage.setItem('userlocation', data.location)
            showMessage({
              message: "Location updated !",
              type: "success",
              icon : 'success',
              duration : 2500
            });
            setloading(false);
            NavigationFunction();
        } else {
          alert('Location update failed please try again', response.data.status);
          setloading(false);
        }
      }).catch(err => {setloading(false),alert(err)})
    }));
  }

  const NavigationFunction = () => {
    if(logged == 0){
      navigation.replace('HomeTabNavigator')
      AsyncStorage.setItem('logged', 1 + '');
    }else{
      navigation.goBack();
    }
  };

  const ButtonView = ({icon, title, subtitle, page}) => {
      return(
        <TouchableOpacity  
          style={[styles.button]}
          onPress={()=> 
            page == 'SelectNowLocation' ? navigation.push('SelectNowLocation', {logged : logged, deliveryareadata : deliveryarealist}) : null
            || page == 'LocationSearch' ? navigation.push('LocationSearch', {logged : logged, deliveryareadata : deliveryarealist}) : null
            || page == 'selfpickupUser' ? setselfpickupalert(true) : null
          }
        >
          <View style={[styles.description]}>
            <Icon name={icon} size={20}/>
            <View style={{marginLeft : 15}}>
                <Text style={[styles.buttontitle]}>{title}</Text>
                <Text numberOfLines={1} style={[styles.buttonsubtitle]}>{subtitle}</Text>
            </View>
          </View>
          <Icon name={'arrow-right'} size={18}/>
        </TouchableOpacity>
      );
  }

  return(
    <View style={[styles.container]}>
    <LoadingComponent visibility={loading}/>
    <ScrollView style={[styles.container, {padding : 10}]}>
      <Animated.View style={[styles.topalertcontainer, {height : animatein}]}>
        <View>
          <Text style={[styles.alerttext]}>{Languages.CannotGetYourLocation}</Text>
        </View>
        <View style={[styles.alertbutton]}>
          <Icon name={'redo'} size={20} color={Colors.white} onPress={GetLocation}/>
        </View>
        <View style={[styles.alertbutton, {right : 50}]}>
          <Icon name={'cog'} size={20} color={Colors.white} onPress={()=>DeviceSettings.location()}/>
        </View>
      </Animated.View>
      <View style={[styles.container]}>
          <Text style={[styles.sectiontitle]}>{Languages.DeliveryOption}</Text>
          <ButtonView icon={'search'} title={Languages.SearchLocation} subtitle={Languages.SearchLocationSubLine} page={'LocationSearch'}/>
          <ButtonView icon={'location-arrow'} title={Languages.SelectMyLocationNow} subtitle={Languages.SelectMyLocationNowSubLine} page={'SelectNowLocation'}/>

          {/* <Text style={[styles.sectiontitle]}>{Languages.SelfPickup}</Text>
          <ButtonView icon={'walking'} title={Languages.SelfPickup} subtitle={Languages.SelfPickupSubLine} page={'selfpickupUser'}/>

          <Text style={[styles.sectiontitle]}>{Languages.DineIn}</Text>
          <ButtonView icon={'utensils'} title={Languages.DineIn} subtitle={Languages.DineInSubLine}/> */}

        <Text style={[styles.sectiontitle]}>{Languages.RecentLocations}</Text>

        <FlatList
          showsVerticalScrollIndicator={false}
          itemDimension={80}
          data={recentLocations}
          spacing={3}
          keyExtractor={(item)=>item.id}
          ItemSeparatorComponent={()=>(<View style={[styles.separator]}></View>)}
          renderItem={({ item }) => (
            <TouchableOpacity onPress={()=>UpdateLocation(item)} style={[styles.recentlocationitemcontainer]}>
              <View style={{flexDirection : 'row', alignItems : 'center'}}>
                <Icon name={'map-marker-alt'} size={20}/> 
                <View style={{width: '88%',}}>
                  <Text style={[styles.recentlocationtitle]} numberOfLines={1}>{item.address}</Text>
                  <Text style={[styles.recentlocationsubtitle]} numberOfLines={1}>{item.shortname}</Text>
                </View>
              </View>
              <Text style={[styles.selecttext]}>{Languages.Select}</Text>
            </TouchableOpacity>
          )}
        />

          <CustomAlert
            displayMode={'alert'}
            displayMsg={Languages.ContinueAsSelfPickup}
            displaymsgtitle={Languages.AreYouSure}
            visibility={selfpickupalert}
            dismissAlert={setselfpickupalert}
            cancellable={false}
            buttons={(
              <>
                <CustomAlertButton buttontitle={Languages.Continue} theme={'alert'} buttonaction={SelfpickupUser}/>
              </>
            )}
          />   

          <CustomAlert
            displayMode={'alert'}
            displayMsg={Languages.ContinueAsSelfPickup}
            displaymsgtitle={Languages.AreYouSure}
            visibility={selfpickupalert}
            dismissAlert={setselfpickupalert}
            cancellable={false}
            buttons={(
              <>
                <CustomAlertButton buttontitle={Languages.Continue} theme={'alert'} buttonaction={SelfpickupUser}/>
              </>
            )}
          />   
      </View>
    </ScrollView>
    </View>
  );
}
export default LocationSettings;