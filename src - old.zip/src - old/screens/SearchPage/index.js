import React, { useEffect, useState } from 'react';
import {View} from 'react-native';
import Icon from 'react-native-vector-icons/Ionicons'; 
import { SearchBar } from 'react-native-elements';
import { Colors, Constants, Languages } from '@common'
import styles from './styles';

const TabNavigator = () => {

    const [searchtext, setsearchtext] = useState('');

    return (
        <View style={[styles.container]}>
            <SearchBar 
                placeholder={Languages.SearchHere}
                onChangeText={(input)=>setsearchtext(input)} 
                value={searchtext}
                containerStyle={{borderRadius : 15, backgroundColor : 'transparent'}}
                inputContainerStyle={{width : '100%', height : 40, backgroundColor : '#fff', borderRadius : 15}}
                inputStyle={{fontFamily : Constants.fontFamilynormal, fontSize : 15}}
            />
        </View>
    );
}

export default TabNavigator;