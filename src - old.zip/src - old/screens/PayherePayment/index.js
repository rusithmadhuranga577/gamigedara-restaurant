/** @format */

import React, { useEffect, useRef } from 'react';
import { connect } from "react-redux";
import {
  SafeAreaView,
  ScrollView,
  Image,
  TouchableOpacity,
  Text,
  Dimensions,
  View,
  Animated
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import styles from './styles';
import { Images } from '@common';
import PayHere from '@payhere/payhere-mobilesdk-reactnative';

    const paymentObject = {
        "sandbox": true,                 // true if using Sandbox Merchant ID
        "merchant_id": "1214592",        // Replace your Merchant ID
        "merchant_secret": "4PW4t8oO24O4uPWKeqp8N98gdtH8Exsu64KHEKAQj4Xp",        // See step 4e
        "notify_url": "http://sample.com/notify",
        "order_id": "ItemNo12345",
        "items": "Hello from React Native!",
        "amount": "50.00",
        "currency": "LKR",
        "first_name": "Saman",
        "last_name": "Perera",
        "email": "samanp@gmail.com",
        "phone": "0771234567",
        "address": "No.1, Galle Road",
        "city": "Colombo",
        "country": "Sri Lanka",
        "delivery_address": "No. 46, Galle road, Kalutara South",
        "delivery_city": "Kalutara",
        "delivery_country": "Sri Lanka",
        "custom_1": "",
        "custom_2": ""
    };

    const PaymentFunction = () => {
        const a = '';
        PayHere.startPayment(
            paymentObject, 
            (paymentId) => {
                console.log("Payment Completed", paymentId);
                a = paymentId;
            },
            (errorData) => {
            },
            () => {
                console.log("Payment Dismissed");
            }
        );
        return(a);
    }

export default PaymentFunction;