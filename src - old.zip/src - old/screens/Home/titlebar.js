/** @format */

import React, { useEffect, useState } from 'react';
import { connect } from "react-redux";
import {
  SafeAreaView,
  ScrollView,
  Image,
  StyleSheet,
  Text,
  useColorScheme,
  View,
  TouchableOpacity
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useIsFocused } from '@react-navigation/native';
import styles from './styles';
import { Images, Languages, Colors } from '@common';
import Icon from 'react-native-vector-icons/Ionicons';

var SharedPreferences = require('react-native-shared-preferences');

const TitleBar =({title, page}) => {

  const navigation = useNavigation();
  const isFocused = useIsFocused();
  const [selfpickupuer, setselfpickupuer] = useState(false);
  const [name, setname] = useState('');

  useEffect(() => {
    SharedPreferences.getItem('fname', fname => {
        setname(fname);
    })
  }, [isFocused])

  return(
    // <TouchableOpacity onPress={()=>navigation.navigate(page, {logged : 1})} style={[styles.titlebar]}>
    <TouchableOpacity activeOpacity={0.8} style={[styles.titlebar]}>
        <Text style={[styles.titlebartext]}>{title}</Text>
        <Icon name={'arrow-forward-outline'} size={25} color={Colors.white}/>
    </TouchableOpacity>
  );
}
export default TitleBar;