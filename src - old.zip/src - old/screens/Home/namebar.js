/** @format */

import React, { useEffect, useState, useRef } from 'react';
import { connect } from "react-redux";
import {
  SafeAreaView,
  ScrollView,
  Image,
  StyleSheet,
  Text,
  Animated,
  View,
  TouchableOpacity
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useIsFocused } from '@react-navigation/native';
import styles from './styles';
import { Images, Languages, Icons } from '@common';
import Icon from 'react-native-vector-icons/FontAwesome';
import moment from 'moment';

var SharedPreferences = require('react-native-shared-preferences');

const NameBar = () => {

  const navigation = useNavigation();
  const name_in = useRef(new Animated.Value(-400)).current;
  const phone_in = useRef(new Animated.Value(200)).current;
  const isFocused = useIsFocused();
  const [selfpickupuer, setselfpickupuer] = useState(false);
  const [name, setname] = useState('');
  const [greetingtext, setgreetingtext] = useState('Hi');

  useEffect(() => {
    setTimeout(() => {
      Animated.timing(
        name_in,
        {
          toValue: 0,
          duration: 600,
        }
      ).start();
      Animated.timing(
        phone_in,
        {
          toValue: 0,
          duration: 600,
        }
      ).start();
    }, 1000);
    SharedPreferences.getItem('fname', fname => {
        setname(fname);
    })
    getGreetingTime();
  }, [isFocused])

  const getGreetingTime = () => {
    var today = new Date()
    var curHr = today.getHours()
    var currentHour = moment(curHr, "H").format("HH");

    if (currentHour < 12) {
      setgreetingtext(Languages.GoodMorning)
    } else if (curHr < 18) {
      setgreetingtext(Languages.GoodAfternoon)
    } else {
      setgreetingtext(Languages.GoodEvening)
    }
  }

  return(
    <View onPress={()=>navigation.navigate('LocationSettings', {logged : 1})} style={[styles.namebar, {marginTop : 60}]}>
        <Animated.View  style={[ styles.namestrip, {transform: [{translateX: name_in}]}]}>
            <Text style={[styles.nametitle]} numberOfLines={1}>{greetingtext}, {name}</Text>
            <Text style={[styles.namesubtitle]}>{Languages.WhatDoYouWantToFind}</Text>
        </Animated.View>
        <Animated.View  style={{ transform: [{translateX: phone_in}] }}>
          <TouchableOpacity>
            <Image source={Icons.oldphone} style={{width : 40, height : 40}}/>
          </TouchableOpacity>
        </Animated.View>
    </View>
  );
}
export default NameBar;