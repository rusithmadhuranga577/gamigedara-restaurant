import { StyleSheet, View, Text, Image, ScrollView, Component, FlatList} from 'react-native';
import React , { useState, useEffect } from 'react';
import { Images, Languages, Colors, Constans } from '@common';
import styles from './styles';
import Icon from 'react-native-vector-icons/FontAwesome5';

function Restaurents(){

  const [isLoading, setLoading] = useState(true);
  const [items, setItems] = useState([]);

  const placeholderData=[
    {
        "id": "1",
        "name": "Gami Gedara Bauddhaloka Junction",
        "image" : "",
        "address" : "Bouddhaloka junction, Kurunegala, Sri Lanka"
    },
    {
        "id": "2",
        "name": "Gami Gedara - Negambo Road",
        "image" : "",
        "address" : "Bouddhaloka junction, Kurunegala, Sri Lanka"
    },
    {
        "id": "3",
        "name": "Gami Gedara - Kandy",
        "image" : "",
        "address" : "Bouddhaloka junction, Kurunegala, Sri Lanka"
    },
    {
        "id": "4",
        "name": "Gami Gedara - Anuradhapura",
        "image" : "",
        "address" : "Bouddhaloka junction, Kurunegala, Sri Lanka"
    }
]

  useEffect(() => {
    fetch('https://oneman.foodsmint.com/api/offers')
      .then((response) => response.json())
      .then((data) => setItems(data))
      .catch((error) => console.error(error))
      .finally(() => setLoading(false));
  }, []);

    return(
        <View>
            <FlatList
                itemDimension={80}
                data={placeholderData}
                style={styles.gridView}
                spacing={3}
                numColumns={2}
                renderItem={({ item }) => (
                    <View style={[styles.container]} >
                        <Image source={{uri : item.image}} style={[styles.image]}/>
                        <Text style={[styles.name]} numberOfLines={2}>{item.name}</Text>
                        <Text style={[styles.address]} numberOfLines={2}>{item.address}</Text>
                        <Image source={Images.Direction} style={[styles.directionimage]}/>
                    </View>
                )}
            />
        </View>
    );
}

export default Restaurents;