import { StyleSheet, View, Text, Image, ScrollView, Component, FlatList} from 'react-native';
import React , { useState, useEffect } from 'react';
import { Images, Languages, Colors, Constans } from '@common';
import styles from './styles';

function TopPicks(){

  const [isLoading, setLoading] = useState(true);
  const [items, setItems] = useState([]);

  const placeholderData=[
    {
        "id": "1",
        "name": "10% OFF",
        "image" : "https://www.theflavorbender.com/wp-content/uploads/2018/03/Chicken-Kottu-Roti-The-Flavor-Bender-Featured-Image-SQ-8.jpg",
    },
    {
        "id": "2",
        "name": "FREE DELIVERY",
        "image" : "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ1XmBAlJ8kMeWMU6UA74JqT-TFBl5bXOgNpLw1yJjJUk0aRM7OouJJRVQN3nKrY-t8AWA&usqp=CAU",
    },
    {
        "id": "3",
        "name": "FREE DELIVERY",
        "image" : "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQFxhgmotlBJu1BnHjQXJbkF3pDV9E9dH41Vg&usqp=CAU",
    },
    {
        "id": "4",
        "name": "FREE DELIVERY",
        "image" : "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQDA8t9hxf44PCY7TjCL1BqS-2IEX9eA4Yr7bnNoZ9qebQtv1YDJOrSyGhPPTTfKkXq2Yg&usqp=CAU",
    },
    {
        "id": "5",
        "name": "FREE DELIVERY",
        "image" : "https://c.ndtvimg.com/2019-08/tfddu9ao_pasta_625x300_13_August_19.jpg",
    }
]

  useEffect(() => {
    fetch('https://oneman.foodsmint.com/api/offers')
      .then((response) => response.json())
      .then((data) => setItems(data))
      .catch((error) => console.error(error))
      .finally(() => setLoading(false));
  }, []);

    return(
        <View>
            <FlatList
                horizontal
                itemDimension={80}
                data={placeholderData}
                style={styles.gridView}
                spacing={3}
                renderItem={({ item }) => (
                    <View style={[styles.container]} >
                        <Image source={{uri : item.image}} style={[styles.image]}/>
                    </View>
                )}
            />
        </View>
    );
}

export default TopPicks;