import { StyleSheet } from "react-native"
import { Colors, Constants } from '@common';

const styles = StyleSheet.create({
    container : {
        width: 100, 
        height: 100,
        backgroundColor: Colors.white,
        elevation : 8,
        margin : 10,
        borderRadius : 5
    },
    image : {
        width : '100%',
        height : '100%',
        borderRadius : 5
    }
})

export default styles;