/** @format */

import React, { useEffect, useState, useRef } from 'react';
import {
    Easing,
    Animated,
    View,
    TouchableOpacity,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { useIsFocused } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/Ionicons'
import { Colors } from '@common';
import styles from './styles';

var SharedPreferences = require('react-native-shared-preferences');

const FloatinCartButton = () => {

    const navigation = useNavigation();
    const isFocused = useIsFocused();
    const animatedValue = useRef(new Animated.Value(1)).current;
    const [show, setshow] = useState(false);

    useEffect(()=>{
        handleAnimation();
        SharedPreferences.getItems(['cartprice', 'cartqty'], cartdata =>{
            if(cartdata[0] == 'null' && cartdata[1] == 'null'){
                setshow(false);
            }else{
                setshow(true);
            }
        });
    }, [isFocused])

    const handleAnimation = () => {
        Animated.loop(
            Animated.sequence([
                Animated.timing(animatedValue, {
                    toValue: 1.19, 
                    duration: 200,
                }),
                Animated.timing(animatedValue, {
                    toValue: 1, 
                    duration: 200,
                }),
            ]),
        { iterations: 3 }
        ).start();
    }

    return(
        <>
        {show ?
        <Animated.View style={[styles.buttoncontainer, {transform : [{scale: animatedValue}]}]}>
            <TouchableOpacity onPress={()=>navigation.push('CartPage')} style={{width : '100%', height : '100%', alignItems : 'center', justifyContent : 'center'}}>
                <Icon name={'cart'} size={25} color={Colors.black}/>
            </TouchableOpacity>
        </Animated.View>:null}
        </>
    );

}

export default FloatinCartButton;