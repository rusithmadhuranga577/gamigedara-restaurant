/** @format */

import React, { useEffect, useState } from 'react';
import { connect } from "react-redux";
import {
  SafeAreaView,
  ScrollView,
  Image,
  StyleSheet,
  Text,
  useColorScheme,
  View,
  TouchableOpacity,
  Dimensions,
  TouchableWithoutFeedback
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { FlatGrid } from 'react-native-super-grid';
import { Images, Constants, Colors, Url } from '@common';

import categoryplaceholder from './categoryplaceholder';

const screenwidth = Dimensions.get('window').width;
var SharedPreferences = require('react-native-shared-preferences');

const CategoryItem =() => {

  const navigation = useNavigation();
  const [categories, setcategories] = useState([]);
  const [foods, setfoods] = useState([]);
  const [menuitems, setmenuitems] = useState([]);

  const [loading, setloading]= useState(false);

  useEffect(() => {
    setloading(true);

    fetch(Url.foodcategory)
    .then((response) => response.json())
    .then((data) => setcategories(data))
    .catch((error) => console.error(error))
    .finally(() => setloading(false))

    fetch(Url.menulisturl)
    .then((response) => response.json())
    .then((data) => setmenuitems(data))
    .catch((error) => console.error(error))
  }, [])


  var tabtitles = [];
  for( i=0; i < categories.length; i++){
    tabtitles.push({cat_order : categories[i].cat_order, category_name : categories[i].category_name});
  }

  const Item = (item) => {
    return(
      <TouchableOpacity onPress={()=>navigation.push('MenuList', {menulist : menuitems, catid : item.cat_order, tabs : tabtitles})}>
        <View style={[styles.itemContainer]}>
          <Image source={{uri : item.image}} style={{width: 70, height: 70, borderRadius: 400/ 2}}/>
          <Text style={[styles.categorytitle]}>{item.category_name}</Text>
        </View>
      </TouchableOpacity>
    );
  }

  const EmptyItem = (item) => {
    return(
      <View>
        <View style={[styles.emptyitemContainer]}>
          <View style={{width: 70, height: 70, borderRadius: 400/ 2, backgroundColor : Colors.gray}}/>
        </View>
      </View>
    );
  }

  return(
    <View style={[styles.gridcontainer]}>
      {loading ?
      <View >
      <FlatGrid
        itemDimension={80}
        keyExtractor={item => item.id}
        maxToRenderPerBatch={10}
        windowSize={10}
        initialNumToRender={10}
        data={categoryplaceholder}
        style={styles.gridView}
        spacing={3}
        renderItem={({ item }) => EmptyItem(item)}
      />
    </View> 
    :
    <View >
      <FlatGrid
        itemDimension={80}
        keyExtractor={item => item.id}
        maxToRenderPerBatch={10}
        windowSize={10}
        initialNumToRender={10}
        data={categories}
        style={styles.gridView}
        spacing={3}
        renderItem={({ item }) => Item(item)}
      />
    </View>}
    </View>
  );
}

const styles = StyleSheet.create({
  gridView: {
    marginTop: 5,
    flex: 1,
  },
  itemContainer: {
    justifyContent: 'flex-end',
    borderRadius: 2,
    padding: 1,
    height: 100,
    alignItems: 'center',
  },
  emptyitemContainer: {
    justifyContent: 'flex-end',
    borderRadius: 2,
    padding: 1,
    height: 100,
    alignItems: 'center',
  },
  itemName: {
    fontSize: 12,
    color: 'red',
    fontWeight: 'bold',
    color: '#707070'
  },
  itemCode: {
    fontWeight: '600',
    fontSize: 12,
    color: '#fff',
  },
  categorytitle : {
      fontFamily : Constants.fontFamilybold,
      color : Colors.black,
      fontSize : 13,
      alignSelf : 'center',
      marginTop : 2
  },
});


export default CategoryItem;