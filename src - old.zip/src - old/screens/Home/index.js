/** @format */

import React, { useEffect, useRef, useState } from 'react';
import { connect } from "react-redux";
import {
  Alert,
  ScrollView,
  BackHandler,
  Text,
  Animated,
  View,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import styles from './styles';
import AddressBar from './addressbar';
import NameBar from './namebar';
import CategoryItem from './CategoryView/categoryitems';
import LatestOffer from './LatestOfferItem/LatestOfferItem';
import TopPickItems from './TopPicks/TopPickItem';
import Restaurents from './RestaurantList/restaurants';
import TitleBar from './titlebar';
import { Images, Languages, Colors } from '@common';
import { CustomAlert, CustomAlertButton } from '@components';
import { useIsFocused } from '@react-navigation/native';
import { Banner } from '@components';
import Icon from 'react-native-vector-icons/FontAwesome';
import FloatinCartButton from './FloatingCartButton';

var SharedPreferences = require('react-native-shared-preferences');

const Home =() => {
  const isFocused = useIsFocused();
  const navigation = useNavigation();
  const addressbarheight = useRef(new Animated.Value(0)).current;
  const [exitalert, setexitalert] = useState(false);

  useEffect(() => {
    const backAction = () => {
      if (navigation.isFocused()) {
        setexitalert(true)
        return true;
      }
    };
    const backHandler = BackHandler.addEventListener("hardwareBackPress", backAction);
    return () => backHandler.remove();
  }, [])

  const AnimeateIn = () => {Animated.timing(addressbarheight,{toValue: -60,duration: 150}).start()}

  const Animeateout = () => {Animated.timing(addressbarheight,{toValue: 0,duration: 150}).start()}

  const onScroll = (e) => {
    const position = e.nativeEvent.contentOffset.y;
    if(position < 100){
      Animeateout();
    }else if(position > 60){
      AnimeateIn();
    }
  }

  return(
    <View style={[styles.container]}>
      <Animated.View style={{width : '100%', height : 60, transform : [{translateY : addressbarheight}], position : 'absolute', zIndex : 99}}>
        <AddressBar/>
      </Animated.View>
      <ScrollView
       onScroll={(e)=>onScroll(e)}
       showsVerticalScrollIndicator={false}
      >
        <NameBar/>
        <Banner/>
        <CategoryItem/>
        <TitleBar title={Languages.ViewOurMenu}/>
        <View>
          <Text style={[styles.latestoffertext]}>{Languages.LatestOffer}</Text>
          <Text style={[styles.bestdealstext]}>{Languages.BestDeals}</Text>
        </View>
        <LatestOffer/>

        <Text style={[styles.latestoffertext]}>{Languages.TopPicks}</Text>
        <TopPickItems/>

        <Text style={[styles.latestoffertext, {marginTop : 15}]}>{Languages.OurRestaurants}</Text>
        <Restaurents/>
      </ScrollView>
      <FloatinCartButton/>

      {/*Exit Alert*/}
      <CustomAlert
          displayMode={'alert'}
          displayMsg={Languages.YouWantToExitApp}
          displaymsgtitle={Languages.AreYouSure}
          visibility={exitalert}
          dismissAlert={setexitalert}
          cancellable={true}
          buttons={(
            <>
              <CustomAlertButton buttontitle={Languages.Yes} theme={'alert'} buttonaction={()=>BackHandler.exitApp()}/>
              <CustomAlertButton buttontitle={Languages.No} theme={'inverse'} buttonaction={()=>setexitalert(false)}/>
            </>
          )}
        />
    </View>
  );
}
export default Home;