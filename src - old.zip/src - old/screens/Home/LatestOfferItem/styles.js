import { StyleSheet } from "react-native";
import { Colors, Constants } from '@common';

const styles = StyleSheet.create({
    container: {
        marginRight: 5,
        height: 150,
        width: 250,
        marginLeft: 5,
        marginTop: 10,
        backgroundColor : Colors.white,
        marginBottom : 20,
        padding : 10,
        borderRadius : 5
    },
    placeholdercontainer: {
        height: 240,
        width: 250,
        marginLeft: 8,
        marginTop: 10,
    },
     imagecontainer: {
         marginRight: 7,
         width: '100%',
         height: 100,
         borderRadius : 5
     },
     DistextStyle: {
        fontWeight: '100',
        fontSize: 12,
        marginRight: 1,
        paddingBottom: 5
    },
     TitletextStyle: {
         color: '#000',
         paddingTop: 5,
         fontWeight: '700',
         paddingBottom: 3,
         fontSize: 16,
         marginRight: 1
     },
     validContainer: {
        alignItems: 'center',
        backgroundColor : Colors.primary,
        width : 180,
        borderRadius: 30,
        height : 25,
        flexDirection: 'row',
        justifyContent: 'center'
     },
     name : {
         fontSize : 15,
         fontFamily : Constants.fontFamilybold,
         color : Colors.white
     },
     promocode : {
        fontSize : 15,
        fontFamily : Constants.fontFamilybold,
        color : Colors.white
     },
     secondline : {
        fontSize : 15,
        fontFamily : Constants.fontFamilynormal,
        color : Colors.black,
     },
     validto : {
        fontSize : 12,
        fontFamily : Constants.fontFamilynormal,
        color : Colors.black
     }
})

export default styles;