import { StyleSheet, View, Text, Image, ScrollView, Component, FlatList} from 'react-native';
import React , { useState, useEffect } from 'react';
import { Images, Languages, Colors, Constans, Url } from '@common';
import styles from './styles';

function LatestOffer(){

  const [isLoading, setLoading] = useState(true);
  const [items, setItems] = useState([]);

  const placeholderData=[
    {
        "id": "1",
        "name": "10% OFF",
        "promocode" : "1717",
        "image" : "https://us.123rf.com/450wm/kesu87/kesu871904/kesu87190400215/121887103-spring-rolls-asian-food-with-various-ingredients-on-stone.jpg?ver=6",
        "secondline":"Test for second line",
        "valid_to":"2021-05-19"
    },
    {
        "id": "2",
        "name": "FREE DELIVERY",
        "promocode" : "1717",
        "image" : "https://st4.depositphotos.com/4590583/28898/i/450/depositphotos_288989496-stock-photo-banner-food-top-view-free.jpg",
        "secondline":"Test for second line"
    }
]

  useEffect(() => {
    fetch(Url.offerurl)
      .then((response) => response.json())
      .then((data) => setItems(data))
      .catch((error) => console.error(error))
      .finally(() => setLoading(false));
  }, []);

        return(
            <View>
                {isLoading ? 
                <FlatList
                horizontal
                itemDimension={80}
                data={placeholderData}
                style={styles.gridView}
                spacing={3}
                renderItem={({ item }) => (
                    <View style={styles.placeholdercontainer} >
                    </View>
                )}
                />
                :<FlatList
                    horizontal
                    itemDimension={80}
                    data={placeholderData}
                    style={styles.gridView}
                    spacing={3}
                    renderItem={({ item }) => (
                        <View style={styles.container} >
                            <View>
                                <View>
                                    <View style={{width: 150, height: 25, backgroundColor: Colors.primary, paddingRight: 10, position: 'absolute', top: 15, zIndex: 3, borderTopRightRadius: 15, borderBottomRightRadius: 15, alignItems: 'center', justifyContent: 'center'}}>
                                        <Text style={[styles.name]} numberOfLines={1}>{item.name}</Text>
                                    </View>
                                    {/* <View style={{height: 30, backgroundColor: '#15a05f', borderRadius: 20, alignItems: 'center', justifyContent: 'center', position: 'absolute', right: 10, bottom: 10, padding: 8, zIndex: 3}}>
                                            <Text style={[styles.promocode]} numberOfLines={1}>{item.promocode}</Text>
                                    </View> */}
                                    <Image style={styles.imagecontainer} source={{uri: item.image}}></Image>
                                </View>
                                        
                                        
                                <View style={{flexDirection: 'column'}}>
                                    <View style={{flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center'}}>
                                        <Text style={[styles.secondline]} numberOfLines={1}>{item.secondline}</Text>
                                    </View>

                                    <View style={{flexDirection: 'row', height: 20, alignContent: 'center', justifyContent: 'flex-start'}}>
                                        <Text style={[styles.validto]} numberOfLines={3}>{Languages.Validtill} {item.valid_to}</Text>
                                    </View>
                                    <Text numberOfLines={2}>{item.description}</Text>
                                </View>
                            </View>
                        </View>
                    )}
                />}
            </View>

        );
}

export default LatestOffer;