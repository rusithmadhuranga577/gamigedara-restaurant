import React, { useEffect, useRef, useState } from 'react';
import { connect } from "react-redux";
import {
  SafeAreaView,
  ScrollView,
  Image,
  FlatList,
  Text,
  Dimensions,
  View,
  TouchableOpacity
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Url, Colors } from '@common';
import styles from './styles';
import axios from 'axios';

const QueryString = require('query-string');

class HorizontalList extends React.Component {

  constructor(props) {
    super(props);
    this.state = {
      items : null,
      selected : 9998
    };
  }

  filterFunction = (id, item) => {
    this.setState({selected : id});
    this.props.filterCategory(id, item.subcategories);
  }

  render(){
    const items = this.props.items;
    const selectedid = this.state.selected;
    const type = this.props.type;
    return(
      <View style={[styles.container, {backgroundColor : type == 'main' ? Colors.gray: null}]}>
        <FlatList
          horizontal
          showsHorizontalScrollIndicator={false}
          itemDimension={80}
          data={items}
          style={styles.gridView}
          spacing={3}
          keyExtractor={(item)=>item.id}
          renderItem={({ item }) => (
            <TouchableOpacity onPress={()=>this.filterFunction(item.id, item)} style={ type == 'main' ? [styles.itemcontainer, {backgroundColor : selectedid == item.id ? Colors.primary : null}] : [styles.itemcontainer, {backgroundColor : selectedid == item.id ? Colors.white : null}]} >
              <Text style={[styles.itemtitlestyle, {fontSize : type == 'main' ? 15 : 13}]}>{item.category_name}</Text>
              { type == 'sub' ?
              <>
                {selectedid == item.id ? 
                <View style={[styles.separator]}/> : null}
              </>:null}
            </TouchableOpacity>
          )}
      />
      </View>
    );
  }
}
export default HorizontalList;