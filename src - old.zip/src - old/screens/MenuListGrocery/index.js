/** @format */

import React, { useEffect, useState, useRef } from 'react';
import {
  ScrollView,
  Image,
  Text,
  Animated,
  View,
  TouchableOpacity,
  Dimensions,
} from 'react-native';
import { useNavigation } from '@react-navigation/native';
import { Constants, Colors, Url, Languages } from '@common';
import { FlatGrid } from 'react-native-super-grid';
import { LoadingComponent } from '@components';
import { useIsFocused } from '@react-navigation/native';
import Icon from 'react-native-vector-icons/Ionicons';
import axios from 'axios';
import NavBar from './navbar';
import styles from './styles';
import HorizontalList from './HorizontalList';

const QueryString = require('query-string');
const screenwidth = Dimensions.get('window').width;
var SharedPreferences = require('react-native-shared-preferences');

const MenuListFGrocery =({route}) => {
  const { resid } = route.params;
  const { restaurantdata } = route.params;
  const popupanimation = useRef(new Animated.Value(0)).current;
  const navigation = useNavigation();
  const isFocused = useIsFocused();

  const sectionListRef = useRef(null);
  const tabbarRef = useRef(null);
  const [allList, setallList] = useState([]);
  const [menulist, setmenulist] = useState([]);
  const [categorylist, setcategorylist] = useState([]);
  const [saleslist, setsaleslist] = useState([]);
  const [subcategories, setsubcategories] = useState([]);

  const [loading, setloading] = useState(false);
  const [hasScrolled, sethasScrolled] = useState(false);
  const [cartdata, setcartdata] = useState(false);
  const [cartitems, setcartitems] = useState([]);

  const shop = [{'shop_name' : 'Gamigedara'}]

  const ITEM_HEIGHT = 100;

  useEffect(()=>{
    Getcartdata();
    FetchMenuList();
  }, [isFocused])

  const FetchMenuList=()=>{
    setloading(true);
    axios.post(Url.fashionmenulisturl, 
    QueryString.stringify({
      restaurant_id : resid,
    }), 
    {
        headers: {"Content-Type": "application/x-www-form-urlencoded",}
    }).then(response => {
      setCategoryList(response.data[0].data);
      setsaleslist(response.data[1].data);
      setmenulist(response.data[2].data);
      setallList(response.data[2].data);
      setloading(false);
    })
  }

  const setCategoryList = (data) => {
    var array = [];
    array.push({'id' : 9998,'category_name' : 'All', 'subcategories' : []}, {'id' : 9999,'category_name' : 'Sale', 'subcategories' : []});
    for(i=0; i < data.length; i++){
      array.push({'id' : data[i].id ,'category_name' : data[i].category_name, 'subcategories' : data[i].subcategories})
      setcategorylist(array);
    }
  }

  const animatein = () => {
    Animated.timing(popupanimation, {
      toValue: 70,
      duration: 500
    }).start();
  };

  const animateout = () => {
    Animated.timing(popupanimation, {
      toValue: 0,
      duration: 600
    }).start();
  };

  const NavigateToCartPage = () => {
    SharedPreferences.getItem('cart_merchant_type', (type) => {
      if(type != 'fashion'){
          navigation.push('CartPage');
      }else{
          navigation.push('FashionItemsCart');
      }
    });
  }

  const Getcartdata = () => {
    SharedPreferences.getItems(['cartprice', 'cartqty', 'cartrestaurantid'], cartdata =>{
      console.log(cartdata[2])
      if(cartdata[0] == 'null' && cartdata[1] == 'null'){
        animateout();
      }else{
        animatein();
        setcartitems(cartdata);
      }
    });
  }

  const getPercentage = (price, original_price) => {
    const price1 = price;
    const price2 = original_price;
    var percentage = 0;

    percentage = ((price2 - price1) / price2 *100).toFixed(0);

    return percentage;
  }

  const filterList = (e, subcategorieslist) => {
    console.log('subcategorieslist', subcategorieslist.length)
    let storsdata = menulist;
    if(!(e == '9999' || e == '9998')){
      setsubcategories(subcategorieslist);
      let text = e.toString()
      let restaurants = allList;
      let filteredName = restaurants.filter((item) => {
        var cat_id_1 = item.main_category_id;
        return cat_id_1.toString().match(text)
      })
      if (!text || text === '') {
        // this.setState({ data: this.props.data })
        // setmenulist();
      setmenulist(allList);
      } else if (Array.isArray(filteredName)) {
        if(filteredName.length == 0){
          setmenulist(filteredName);
          // this.setState({ stores: filteredName });
        }else{
          setmenulist(filteredName);
          // this.setState({ stores: filteredName });
        }
      }
    }else if(e == '9998'){
      console.log('All')
      setmenulist(allList);
      setsubcategories([]);
    }else if(e == '9999'){
      console.log('Sale')
      setmenulist(saleslist);
      setsubcategories([]);
    }
    
  }

  const filterList2 = (e) => {
    let storsdata = menulist;
    if(e != ''){
      let text = e.toString()
      let restaurants = allList;
      let filteredName = restaurants.filter((item) => {
        var cat_id_1 = item.food_category_id;
        return cat_id_1.toString().match(text)
      })
      if (!text || text === '') {
        // this.setState({ data: this.props.data })
        // setmenulist();
      setmenulist(allList);
      } else if (Array.isArray(filteredName)) {
        if(filteredName.length == 0){
          setmenulist(filteredName);
          // this.setState({ stores: filteredName });
        }else{
          setmenulist(filteredName);
          // this.setState({ stores: filteredName });
        }
      }
    }    
  }

  const nav = (item) => {
    console.log(item.foodtype)
    navigation.push('FoodItem' , {name: item.food_name, price: item.price, image: item.image_large, id: item.id , foodtypes : item.foodtype, secondline: item.second_line,  addons: item.addons.length == 0? null : item.addons[0].addonitems, restaurant_id : restaurantdata.id, restaurantdata : restaurantdata });
  }

  var i = 0;
  const RenderItem = (item) => {
    return(
      <>
        <View>
        <TouchableOpacity onPress={()=>item.available == 0 ? null : nav(item)} style={[styles.itemcontainer, {opacity : item.available == 0 ? 0.4 : 1}]}>
          <View>
              {item.image_thumb == null ? null : <Image style={styles.image} source={{uri: item.image_thumb}} ></Image>}      
          </View>
          <View style={{width : '100%', padding : 7}}>
              <Text numberOfLines={1} style={[styles.foodname]}>{item.food_name}</Text>
              {/* {item.second_line == '' ? null : <Text numberOfLines={2} style={[styles.foodsecondline]}>{item.second_line}</Text>} */}
            <View>
              <Text style={[styles.price, {fontFamily : Constants.fontFamilybold, fontSize : 17}]}>{Languages.Rs}{Number(item.price).toFixed(2)}</Text>
              {item.price < item.original_price ? 
              <View style={{flexDirection : 'row', alignItems : 'center'}}>
                <Text  style={[styles.price, {textDecorationLine: 'line-through', color : Colors.darkgray}]}>{Languages.Rs}{Number(item.original_price).toFixed(2)}</Text>
                <View style={[styles.populerbadge]}>
                <Text style={[styles.percentage]}>{getPercentage(item.price, item.original_price)}% OFF</Text>
                </View>
              </View>:null}
            </View>
          </View>
                                        
          
        </TouchableOpacity>
        {item.available == 0 ?
        <View style={[styles.itemoverlay]}>
          <Text style={[styles.notavailabletext]}>{Languages.ItemNotAvailable}</Text>
        </View>
        :null}
        </View>
      </>
    );
  }

  const CartPopup = () => {
    return(
      <TouchableOpacity onPress={NavigateToCartPage}>
          <Animated.View style={[styles.cartpopupcontainer, {height : popupanimation}]}>
            <View style={{alignSelf : 'center', marginLeft : 25}}>
              <Text style={[styles.cartpricetext]}>{Languages.Rs}{Number(cartitems[0]).toFixed(2)}</Text>
              <Text style={[styles.cartqtytext]}>{cartitems[1]} {Languages.ItemsinCart}</Text>
            </View>
            <Icon name={'cart'} size={35} style={[styles.cartpopupicon]} color={Colors.white}/>
          </Animated.View>
      </TouchableOpacity>
    );
  }

  const RestaurantDetails = () => {
    const item = restaurantdata;
    return(
      <View style={[styles.res_banner_overlay]}>
        <Text style={[styles.restaurantname]}>{item.name}</Text>
        <Text style={[styles.restaurantdescription]}>{item.company} - {item.city}</Text>
        <View style={{width : '100%', flexDirection : 'row', alignItems : 'center'}}>
          <Icon name={'star'} style={{paddingRight : 5}} size={12} color={Colors.alertyellow}/>
          <Text style={[styles.restaurandeliverytime]}>{item.def_rating} ({item.def_rating_count})</Text>
          <Text style={[styles.restaurandeliverytime]}>   | </Text>
          <Icon name={'bicycle-outline'} style={{paddingRight : 10, paddingLeft : 10}} size={18} color={Colors.black}/>
          <Text style={[styles.restaurandeliverytime]}>{Languages.Delivery} {Languages.Within} {item.fashion_delivery_time}</Text>
          <Text style={[styles.restaurandeliverytime]}>   |   </Text>
          <Icon name={'time-outline'} style={{paddingRight : 5}} size={12} color={Colors.black}/>
          <Text style={[styles.restaurandeliverytime]}>{Number(item.open_time).toFixed(2)} - {Number(item.close_time).toFixed(2)}</Text>
        </View>
        <View style={{width : '100%', flexDirection : 'row', alignItems : 'center'}}>
          
        </View>
      </View>
    );
  }

  const MainView = () => {
    return(
      <ScrollView style={{width : '100%', height : '100%', backgroundColor : '#fff'}}>
      <LoadingComponent visibility={loading}/>
      <Image source={{uri : restaurantdata.cover_banner}} style={{width: '98%', height : 200, alignSelf : 'center', resizeMode : 'cover'}}/>
      <RestaurantDetails/>
      <HorizontalList items={categorylist} filterCategory={(data, subcategorieslist)=>filterList(data, subcategorieslist)} type={'main'}/>
      <HorizontalList items={subcategories} filterCategory={(data)=>filterList2(data)} type={'sub'}/>
      <FlatGrid
        data={menulist}
        itemDimension={130}
        spacing={3}
        renderItem={({ item}) => RenderItem(item)}
      />
      </ScrollView>
    );
  }

  return (
    <>
      {MainView()}
      <NavBar title={restaurantdata.name}/>
      <CartPopup/>
    </>
  );
}

export default MenuListFGrocery;