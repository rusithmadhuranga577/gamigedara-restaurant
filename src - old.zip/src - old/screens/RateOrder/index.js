import { StyleSheet, View, Text, Image, ScrollView, FlatList} from 'react-native';
import React , { useState, useEffect } from 'react';
import { Images, Languages, Colors, Constans, Url } from '@common';
import { LoadingComponent, Button } from '@components';
import { useIsFocused } from '@react-navigation/native';
import { useNavigation } from '@react-navigation/native';
import styles from './styles';
import TopContent from './restaurantdetails';
import OrderRate from './orderrate';
import DriverRate from './driverrate';
import ItemsList from './ItemsList';
import axios from 'axios';
import HeaderBar from './headerbar';

const QueryString = require('query-string');

class RateOrder extends React.Component{

    constructor(props) {
        super(props);

        this.state = {
            itemsratingarray : [],
            orderrate : 1,
            driverrate : 1,
            orderitems : [],
            restaurant : []
        };
    }

    componentDidMount(){
        const route = this.props.route.params;
        const orderid = route.orderid;
        axios.post(Url.getorderdetailsurl, 
        QueryString.stringify({
            orderid : orderid
        }),
        {
            headers: {"Content-Type": "application/x-www-form-urlencoded",}
        })
        .then(response => {
            const orderitems = response.data.order.orderitems;
            const orderrate = response.data.order.rating;
            this.createArray(orderitems);
            this.getRestaurantData(response.data.order.restuarant_details_id)
        }).catch(error => {
            console.log(error);
        })
    }

    getRestaurantData=(id)=>{
        const resid = id;
        axios.post(Url.getrestaurantdetailsurl, 
        QueryString.stringify({
            restaurant_id : resid
        }),
        {
            headers: {"Content-Type": "application/x-www-form-urlencoded",}
        })
        .then(response => {
            console.log(response.data);
            this.setState({restaurant : response.data});
        }).catch(error => {
            console.log(error);
        })
    }

    createArray=(data)=>{
        const orderitems = data;
        var array = [];
        for(i=0; i< orderitems.length; i++){
            console.log(orderitems[i].food_name, orderitems[i].id, orderitems[i].liked);
            array.push({'food_name' : orderitems[i].food_name, 'id' : orderitems[i].id, 'liked' : 1, 'image_large' : orderitems[i].image_large});
        }
        this.setState({orderitems : array});
        this.setState({itemsratingarray : array});
    }

    cancelFunction=()=>{
        console.log('pressed')
    }

    RateFunction=()=>{
        const { navigation } = this.props;
        const route = this.props.route.params;
        const orderid = route.orderid;
        const driver_rate = this.state.driverrate;
        const order_rate = this.state.orderrate;
        const items_rate = this.state.itemsratingarray;

        var ratearray = [];
        ratearray.push({'order_id' : orderid,'order_rate' : order_rate, 'driver_rate' : driver_rate, 'items_rate' : items_rate})
        console.log(ratearray[0]);

        axios.post(Url.rateorderurl, 
        QueryString.stringify(ratearray[0]),
        {headers: {"Content-Type": "application/x-www-form-urlencoded"}})
        .then(response => {
            console.log(response.data);
        }).catch(error => {
            console.log(error);
        })
        navigation.replace('HomeTabNavigator');
        // const data = state.itemsratingarray;
        // var output = [];
        // for( i=0; i < data.length; i++){
        //     output.push({'item_id' : data[i].id ,'item_name' : data[i].item_name, 'rating' : data[i].liked == true ? 1 : 0})
        // }
        // console.log(output)
    }

    render(){
        return(
            <View  style={[styles.container]}>
                <HeaderBar action={this.cancelFunction}/>
                <ScrollView>
                    <TopContent data={this.state.restaurant}/>
                    <View style={[styles.separator]}/>
                    <OrderRate data={this.state.orderrate} GetStates={(state)=>this.setState({orderrate : state})}/>
                    <View style={[styles.separator]}/>
                    <DriverRate data={this.state.driverrate} GetStates={(state)=>this.setState({driverrate : state})}/>
                    <View style={[styles.separator]}/>
                    <ItemsList data={this.state.orderitems} GetArray={(array)=>this.setState({itemsratingarray : array})}/>
                </ScrollView>
                <View style={[styles.buttonholder]}>
                    <Button title={Languages.RateNow} action={()=>this.RateFunction()}/>
                </View>
            </View>
        );
    }
}

export default function(props){
    const navigation = useNavigation();
    return <RateOrder {...props} navigation={navigation} />;
} 