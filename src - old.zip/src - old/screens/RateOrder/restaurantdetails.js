import { StyleSheet, View, Text, Image, ScrollView, Component, FlatList} from 'react-native';
import React , { useState, useEffect } from 'react';
import { Images, Languages, Colors, Constans, Url, Store } from '@common';
import { LoadingComponent } from '@components';
import { useIsFocused } from '@react-navigation/native';
import styles from './styles';

function TopContent({data}){
    
    //const isFocused = useIsFocused();

    return(
        <View style={[styles.restaurantdetailsbar]}>
            <View style={[styles.imageholder]}>
                <Image source={{uri : data.logo}} style={[styles.image]}/>
            </View>
            <View>
                <Text numberOfLines={1} style={[styles.restaurantname]}>{data.name}</Text>
                <Text numberOfLines={3} style={[styles.restaurantnamesubline]}>{data.address_line_1}, {data.address_line_2}</Text>
            </View>
        </View>
    );
}

export default TopContent;