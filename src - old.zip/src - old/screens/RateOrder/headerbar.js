import { StyleSheet, View, Text, Image, ScrollView, TouchableOpacity, FlatList} from 'react-native';
import React , { useState, useEffect } from 'react';
import { Images, Languages, Colors, Constans, Url, Store } from '@common';
import { LoadingComponent } from '@components';
import { useIsFocused } from '@react-navigation/native';
import { useNavigation } from '@react-navigation/native';
import styles from './styles';

const HeaderBar=(props)=>{
    return(
        <View style={[styles.headerbar]}>
            <Text style={[styles.headertitle]}>{Languages.RateOrder}</Text>
            <TouchableOpacity onPress={()=>props.action()} style={[styles.canceltextholder]}>
                <Text style={[styles.canceltext]}>{Languages.Cancel}</Text>
            </TouchableOpacity>
        </View>
    );
}

export default HeaderBar;