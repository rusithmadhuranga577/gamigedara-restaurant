import React, { useEffect, useState } from 'react';
import {
  Text,
  FlatList,
  View
} from 'react-native';
import AsyncStorage from '@react-native-community/async-storage';
import firestore from '@react-native-firebase/firestore';
import styles from './styles';
import Container from './container';
import { Languages } from '@common';

const OrdersList = ({route, navigation}) => {
    const [loading, setloading] = useState(false);
    const [orderslist, setorderslist] = useState([]);

    useEffect(()=>{
        getFirestoreData();
    }, [])

    const getFirestoreData = () => {
        AsyncStorage.getItem('userid', (err, userid) => {
            const uid = Number(userid);
            firestore()
            .collection('orders')
            .where('customer_id', '==', userid.toString())
            // .orderBy('order_id', 'desc')
            .onSnapshot(documentSnapshot => {
                if(documentSnapshot != null){
                    setorderslist(documentSnapshot._docs);
                }
            })  
        });
    }
    return(
        <View style={[orderslist.length  == 0 ? styles.noordercontainer : styles.container]}>
            {orderslist.length == 0 ?
                <Text style={[styles.noorderstext]}>{Languages.YouHaveNOrders}</Text>
            :
            <FlatList
                itemDimension={80}
                data={orderslist}
                spacing={3}
                renderItem={({ item }) => (
                    <Container data={item}/>
                )}
            />}
        </View>
    );
}

export default OrdersList;