import React, { useEffect, useRef, useState } from 'react';
import { View, BackHandler, Text, Image, ScrollView, FlatList } from 'react-native';
import { Store, Languages, Images, Url } from '@common';
import styles from '../styles';

const OrderItemsList = ({items}) => {

    const RenderItem = (item) => {
        return(
            <View>
                <View style={[styles.orderitemcontainer]}>
                    <View style={{flexDirection : 'row', alignItems : 'center'}}>
                        <View style={[styles.orderitemqtyholder]}>
                            <Text>{item.qty}</Text>
                        </View>
                        <Text>{item.food_name}</Text>
                    </View>
                    <Text>{Languages.Rs}{Number(item.price).toFixed(2)}</Text>
                </View>
            </View>
        );
    }

    return(
        <View style={{marginBottom : 10}}>
            <FlatList
                itemDimension={80}
                staticDimension={300}
                fixed
                spacing={5}
                ItemSeparatorComponent={()=>(<View style={[styles.itemseparator]}/>)}
                data={items}
                key={item => item.id}
                spacing={3}
                renderItem={({ item, index }) => RenderItem(item)}
            />
        </View>
    );
}

export default OrderItemsList;