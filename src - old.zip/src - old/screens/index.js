import Splash from "./Splash";
import Login from './Login'
import PhoneNumberInput from './Login/PhoneInputModel';
import UsernamepassowrdLogin from './Login/UsernamePasswordloginModel';
import VerifyOtp from './Login/VerifyCodeModel';
import CreateNewAccount from "./CreateNewAccount";
import LocationSettings from "./LocationSettings";
import LocationSearch from "./LocationSettings/LocationSearch";
import SelectNowLocation from "./LocationSettings/SelectNowLocation";
// import SetProfileImage from "./CreateNewAccount/SetProfileImage";
import MenuList from "./MenuList/menulist";
import FoodItem from "./FoodItem";
import CartPage from "./Cart";
import Promotion from "./Promotion";
import PhoneNumberChange from "./SettingsPages/PhoneNumberChange";
import UpdateUserInfo from './UpdateUserInfo';
import Account from "./SettingsPages/Account";
import Offers from "./Offers";
import WebViewPage from './Webview';
import RateOrder from "./RateOrder";
import OrderStatus from './OrderStatus';
import MulirestaurantHome from './MulirestaurantHome';
import RestaurantList from "./RestaurantList";
// import PayherePaymernt from './PayherePayment';
import OrdersScreen from './Orders/TabNavigator';
// import SearchPage from './SearchPage';
import OrderView from "./Orders/OrderView";
// import FashionItemsCart from "./FashionItemsCart";
import AddAddress from "./SettingsPages/AddAddress";
import MenulistCategory from "./MenuListCategories";

export {
  Splash,
  Login,
  PhoneNumberInput,
  UsernamepassowrdLogin,
  VerifyOtp,
  CreateNewAccount,
  LocationSettings,
  LocationSearch,
  SelectNowLocation,
  // SetProfileImage,
  MenuList,
  FoodItem,
  CartPage,
  Promotion,
  PhoneNumberChange,
  UpdateUserInfo,
  Account,
  Offers,
  WebViewPage,
  RateOrder,
  OrderStatus,
  MulirestaurantHome,
  RestaurantList,
  // PayherePaymernt,
  OrdersScreen,
  // SearchPage,
  OrderView,
  // FashionItemsCart,
  AddAddress,
  MenulistCategory
};
