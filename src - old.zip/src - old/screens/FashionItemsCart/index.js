import React, { useEffect, useState, useMemo } from 'react';
import {
  View,
  TextInput,
  ScrollView,
  Text
} from 'react-native';
import AsyncStorage from '@react-native-community/async-storage';
import {LoadingComponentCart} from '@components';
import { Colors, Constants, Languages, Url } from '@common';
import { useNavigation } from '@react-navigation/native';
import { useIsFocused } from '@react-navigation/native';
import { RadioButtonOrderScreen, Button, CustomAlertButton, CustomAlert } from '@components';
import styles from './styles';
import SectionTitleStrip from './Components/SectionTitleStrip';
import ItemsList from './Components/ItemsList';
import PromotionButton from './Components/promotionbutton';
import OrderCharges from './Components/ordercharges';
import OrderTypeOptions from './OderTypeOptions/index';
import axios from 'axios';
import { showMessage, hideMessage } from "react-native-flash-message";
import { Service } from '@notificationservice';
import PayHere from '@payhere/payhere-mobilesdk-reactnative';

const QueryString = require('query-string');
var SharedPreferences = require('react-native-shared-preferences');

const FashionItemsCart = () => {

    const navigation = useNavigation();
    const isFocused = useIsFocused();
    const [clearcartalert, setclearcartalert] = useState(false);
    const [nodeliveryinfoalert, setnodeliveryinfoalert] = useState(false);

    const [totalloading, settotalloading] = useState(true);
    const [deliveryinfoarray, setdeliveryinfoarray] = useState([]);
    const [orderchargesarray, setorderchargesarray] = useState([]);
    const [selectedrestaurantdata, setselectedrestaurantdata] = useState([]);

    const [servicecharge, setservicecharge] = useState(50);
    const [restauranttype, setrestauranttype] = useState('');
    const [restaurantid, setrestaurantid] = useState('');
    const [restaurantname, serestaurantname] = useState('');
    const [deliveryname, setdeliveryname] = useState('');
    const [cartitems, setcartitems] = useState([]);
    const [total, settotal] = useState(0);
    const [userid, seuserid] = useState(0);
    const [deliverynote, setdeliverynote] = useState(0);
    const [ordertype, setordertype] = useState(0);
    const [paymentmethod, setpaymentmethod] = useState('COD');
    const [appliedpromo, setappliedpromo] = useState([]);
    const [promocodeshave, setpromocodeshave] = useState(false);

    const onRegister =(token)=> {
        this.setState({registerToken: token.token, fcmRegistered: true});
    }
    
    const notif = useMemo(() => {
        return new Service(onRegister);
    }, [])

    const paymentoptions = [{id : 1, label : 'Cash on Delivery', price : total, data : 'COD'}, {id : 1, label : 'Card Payment', price : total, data : 'CARD'}];

    useEffect(()=>{
        SharedPreferences.getItems(['userid', 'deliveryname'], (user) => {
            seuserid(user[0]);
            setdeliveryname(user[1]);
        });
        SharedPreferences.getItem('appliedpromo', (promo) => {
            if(promo){
                const appliedpromo = JSON.parse(promo);
                setappliedpromo(appliedpromo);
                setpromocodeshave(true);
            }else{
                setappliedpromo([]);
                setpromocodeshave(false);
            }
        });
        AsyncStorage.getItem('cartitems', (err, cartitems)=>{
            const cartitemsdata = JSON.parse(cartitems);
            if(cartitemsdata != null){
                setrestaurantid(cartitemsdata[0].restaurant_id);
                serestaurantname(cartitemsdata[0].restaurant_name);
                setcartitems(cartitems);
                getSelectedRestaurantData(cartitemsdata[0].restaurant_id);
            }            
        });
    }, [isFocused])

    const getSelectedRestaurantData = (id) => {
        settotalloading(true);
        axios.post(Url.getrestaurantdetailsurl, 
        QueryString.stringify({
            restaurant_id : id,
        }), 
        {
            headers: {"Content-Type": "application/x-www-form-urlencoded",}
        }).then(response => {
            const res_data = response.data;
            setrestauranttype(res_data.restaurant_type);
            settotalloading(false);
        });
    }

    const checkInfoAvailable = () => {
        if(deliveryinfoarray.infohave == true){
            SetOrder();
        }else{
            setnodeliveryinfoalert(true);
        }
    }

    const SetOrder = () => {
        var t = new(Date);
        var hour = t.getHours();
        var minutes = t.getMinutes();
        var seconds = t.getSeconds();
        var year = t.getFullYear();
        var month = t.getMonth();
        var day = t.getDate();
        var payhere_orderid = `${hour}${minutes}${year}${month}${day}-${userid}`

        const paymentObject = {
            "sandbox": true,
            "merchant_id": "1214592",
            "merchant_secret": "48fczfshYB94uR3rfNS4Wq4jtSCsEG5Ux8MLvH9GuJnf",
            "notify_url": "http://www.gemigedara.lk/notify",
            "order_id": payhere_orderid,
            "items": "Mr Picker",
            "amount": orderchargesarray.total,
            "currency": "LKR",
            "first_name": deliveryinfoarray.fname,
            "last_name": deliveryinfoarray.lname,
            "email": deliveryinfoarray.email,
            "phone": deliveryinfoarray.phonenumber,
            "address": deliveryinfoarray.useraddress,
            "city": deliveryinfoarray.city,
            "country": "Sri Lanka",
            "delivery_address": deliveryinfoarray.useraddress,
            "delivery_city": deliveryinfoarray.city,
            "delivery_country": "Sri Lanka",
            "custom_1": "",
            "custom_2": ""
        };
        
        if(paymentmethod == 'CARD'){
            PayHere.startPayment(
                paymentObject, 
                (paymentId) => {PostOrder(paymentId, 1)},
                (errorData) => {alert("Payment Error", errorData)},
                () => {console.log("Payment Dismissed")}
            );
        }else{
            PostOrder('', 0)
        }
    }

    const PostOrder = (payhereid, paid) => {
        settotalloading(true);
        const promo_code = orderchargesarray.promotion !== null ? orderchargesarray.promotion.promocode : '';
        const orderitems = cartitems;

        var ordertype = '';
        const ordertypeid = deliveryinfoarray.ordertype;
        if(ordertypeid == 0){
            ordertype = 'Delivery';
        }else if(ordertypeid == 1){
            ordertype = 'SelfPickup';
        }else if(ordertypeid == 2){
            ordertype = 'DineIn';
        }

        const orderarray = [{
            customers_id : userid,
            ordertype : ordertype,
            order_shedule_type : 0,
            food_amount : deliveryinfoarray.cartprice,
            delivery : orderchargesarray.deliverycharge,
            small_order : 0,
            discount : orderchargesarray.promovalue,
            order_total : orderchargesarray.total,
            orderforfriend : 0,
            delivery_name : deliveryname,
            delivery_address : deliveryinfoarray.useraddress,
            delivery_lon : 0,
            delivery_lat : 0,
            delivery_phone : deliveryinfoarray.phonenumber,
            estimate_time : '',
            notes : deliverynote,
            orderitems : orderitems,
            promocode : promo_code,
            paymentmode : paymentmethod,
            payhereid : payhereid,
            restuarant_details_id : restaurantid,
            restaurant_name : restaurantname,
            paid : paid
        }]
        console.log(orderarray)
        axios.post(Url.neworderurl,
            QueryString.stringify(
                orderarray[0],
            ),
            {
              headers: {"Content-Type": "application/x-www-form-urlencoded",}
            })
            .then(response => {
            if(response.data.status == 1){
                const orderid = response.data.id;
                showMessage({
                  message: "Order placed successfully",
                  type: "success",
                  icon : 'success',
                  duration : 3000
                });
                settotalloading(false);
                ClearCart();
                navigation.replace('OrderView', {title : `#${orderid} Order`, orderid : orderid});
                notif.localNotif('sample.mp3', Languages.Orderplaced, Languages.OrderPlacedSuccessfully);
            }else{
                showMessage({
                  message: "Something went wrong, please try again.",
                  type: "danger",
                  icon : 'danger',
                  duration : 3000
                });
                settotalloading(false);
            }
        }).catch(error => {
            console.log(error);
            settotalloading(false);
        })
    }

    const ClearCart = () => {
        AsyncStorage.removeItem('cartitems');
        SharedPreferences.removeItem('cartprice');
        SharedPreferences.removeItem('cartqty');
        SharedPreferences.removeItem('cartrestaurantid');
        SharedPreferences.removeItem('appliedpromo');
    }

    const ClearCartAndBack = () => {
        AsyncStorage.removeItem('cartitems');
        SharedPreferences.removeItem('cartprice');
        SharedPreferences.removeItem('cartqty');
        SharedPreferences.removeItem('cartrestaurantid');
        SharedPreferences.removeItem('appliedpromo');
        showMessage({
            message: "Cart cleared",
            type: "success",
            icon : 'success',
            duration : 2000
        });
        navigation.goBack();
    }

    const SetNewRestaurantData = (value) => {
        setrestaurantid(value.id);
        serestaurantname(value.label);
        getSelectedRestaurantData(value.id);
    }

    return(
        <View style={[styles.container]}>
            <LoadingComponentCart visibility={totalloading} subtitle={Languages.CalculatingTotal}/>
            <ScrollView>
                <OrderTypeOptions 
                    setTime={(time)=>console.log(time)} 
                    getType={(type)=>(setdeliveryinfoarray(type), setordertype(type.ordertype))} 
                    navigation={navigation} restaurantname={restaurantname} 
                    restauranttype={restauranttype} 
                    getNewRestaurant={(value)=>SetNewRestaurantData(value)}
                    res_id={restaurantid}
                    res_data={selectedrestaurantdata}
                />
                <SectionTitleStrip action={()=>setclearcartalert(true)}/>
                <ItemsList/>
                <PromotionButton/>
                <TextInput 
                    value={deliverynote}
                    placeholder={Languages.AddDeliveryNote}
                    onChangeText={text => setdeliverynote(text)}
                    style={[styles.textinput]}
                    placeholderTextColor={'rgba(0,0,0,0.4)'}
                />  
                <OrderCharges 
                    ordertype={ordertype} 
                    getordercharges={(ordercharges)=>settotal(ordercharges)} 
                    restaurantid={restaurantid}
                    getloadingstate={(state)=> settotalloading(state)} 
                    promotion={promocodeshave ? appliedpromo : 'no promo'} 
                    getchargersarray={(array)=>setorderchargesarray(array)}
                    navigation={navigation}
                /> 
                <Text style={[styles.paymentsummerytext, {marginLeft : 10, marginTop : 20}]}>{Languages.PayWith}</Text>
                <RadioButtonOrderScreen
                    data={paymentoptions}
                    initial={1}
                    box = {false}
                    selectedBtn={(e) => {setpaymentmethod(e.data)}}            
                    animationTypes= {['pulse', 'shake', 'rotate']}
                />
                <View style={[styles.buttonholder]}>
                    <Button title={Languages.PlaceOrder} action={checkInfoAvailable}/>
                </View>
            </ScrollView>

            {/* Cannot apply promo code alert */}
            <CustomAlert
                displayMode={'alert'}
                displayMsg={Languages.ClearCart}
                displaymsgtitle={Languages.AreYouSure}
                visibility={clearcartalert}
                cancellable={false}
                buttons={(
                <>
                    <CustomAlertButton buttontitle={Languages.Yes} theme={'alert'} buttonaction={ClearCartAndBack}/>
                    <CustomAlertButton buttontitle={Languages.Cancel} theme={'inverse'} buttonaction={()=>setclearcartalert(false)}/>
                </>
                )}>
            </CustomAlert>

            {/* No delivery info alert */}
            <CustomAlert
                displayMode={'alert'}
                displayMsg={Languages.PleaseAddDeliveryInfo}
                visibility={nodeliveryinfoalert}
                cancellable={false}
                buttons={(
                <>
                    <CustomAlertButton buttontitle={Languages.Ok} theme={'alert'} buttonaction={()=>{setnodeliveryinfoalert(false), navigation.push('AddAddress')}}/>
                </>
                )}>
            </CustomAlert>
        </View>
    );
}
export default FashionItemsCart;