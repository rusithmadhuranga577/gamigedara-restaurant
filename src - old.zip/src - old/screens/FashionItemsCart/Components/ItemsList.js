import React, { useEffect, useState } from 'react';
import {View, Text, FlatList, ScrollView, Image} from 'react-native';
import AsyncStorage from '@react-native-community/async-storage';
import PropTypes from 'prop-types';
import { Store, Colors, Icons, Languages } from '@common';
import Icon from 'react-native-vector-icons/FontAwesome5';
import styles from '../styles';
import { TouchableOpacity } from 'react-native-gesture-handler';

var SharedPreferences = require('react-native-shared-preferences');

const ItemsList = () => {

    const [cartitems, setcartitems] = useState([]);

    useEffect(()=>{
        AsyncStorage.getItem('cartitems', (err, cartitems)=>{
            setcartitems(JSON.parse(cartitems))
            console.log(JSON.parse(cartitems))
        })
    },[])
    
    const RenderAddonItem = (item) => {
        return(
            <Text numberOfLines={1} style={[styles.cartitemaddon]}>{item.name} {item.price == 0 ? null : `(${Languages.Rs} ${item.price})`}</Text>
        );
    }

    const RenderCartItem = (item) => {
        return(
            <View style={[styles.cartitemcontainer]}>
                <View style={[styles.cartitemimageholder]}>
                    <Image source={{uri : item.item_image}} style={[styles.cartitemimage]}/>
                </View>
                <View style={{width : '60%'}}>
                    <Text numberOfLines={1} style={[styles.cartitemtitle]}>{item.item_name}</Text>
                    <Text numberOfLines={1} style={[styles.cartitemportion]}>{item.item_type_name}({Languages.Rs}{item.item_type_price} × {item.item_qty})</Text>
                    {item.addons.length ?
                        <ScrollView style={{marginTop : 5, width : '80%'}}>
                            <FlatList
                                itemDimension={80}
                                staticDimension={300}
                                fixed
                                spacing={5}
                                data={item.addons}
                                keyExtractor={item => item.id}
                                renderItem={({ item }) => RenderAddonItem(item)}
                            />
                        </ScrollView> : null}
                    {item.item_Preparation_note ? <Text numberOfLines={1} style={[styles.cartitempreparationnote]}>Notes : {item.item_Preparation_note}</Text> : null}
                </View>
                <Text numberOfLines={1} style={[styles.cartitemtotal]}>{Languages.Rs}{Number(item.item_total).toFixed(2)}</Text>
            </View>
        );
    }

    return(
        <View style={{width : '100%', backgroundColor : '#aaa'}}>
        <FlatList
            itemDimension={80}
            staticDimension={300}
            fixed
            spacing={5}
            data={cartitems}
            keyExtractor={item => item.id}
            renderItem={({ item }) => RenderCartItem(item)}
        />
        </View>
    );
}

export default ItemsList;