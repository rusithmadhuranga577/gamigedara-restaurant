import React from 'react';
import {View, Text} from 'react-native';
import AsyncStorage from '@react-native-community/async-storage';
import PropTypes from 'prop-types';
import {convertSpeed, getDistance, getPreciseDistance} from 'geolib';
import { Languages, Store, Url, Constants } from '@common';
import axios from 'axios';
import { Button, CustomAlert, CustomAlertButton } from '@components';
import styles from '../styles';

const QueryString = require('query-string');
var SharedPreferences = require('react-native-shared-preferences');

class OrderCharges extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            loading : true,
            promoavailable : false,
            additionalchargeavailable : false,
            cannotapplypromoalert : false,
            subtotal : 0,
            additionalcharge : 0,
            additionalchargename : '',
            promotion : [],
            deliverycharge : 0,
            total : 0,
            ordertype : 0,
            promovalue : 0,
            m_lat : 0,
            m_lan : 0
        };
        this.getordercharges = this.getordercharges.bind(this);
        this.getloadingstate = this.getloadingstate.bind(this);
        this.getchargersarray = this.getchargersarray.bind(this);
    }

    componentDidMount() {
        this.getloadingstate(true);
        this.getrestaurantdata();
        this._unsubscribe = this.props.navigation.addListener('focus', () => {
            this.getrestaurantdata();
        });
    }

    componentDidUpdate() {
        if(this.state.ordertype != this.props.ordertype){
            setTimeout(() => {this.getloadingstate(true)}, 1000);
            this.getloadingstate(true);
            this.setState({ordertype: this.props.ordertype});
            this.setState({promotion: this.state.promotion});
            this.settotal();
            this.getrestaurantdata();
        }
        this.getordercharges(this.state.total);
        this.getchargersarray(this.state);
    }

    getDeliveryCharge(d_charge){
        console.log('Delivery Charge => ', d_charge)
        const deliverycharge = Number(d_charge);
        this.setState({deliverycharge: deliverycharge});
        this.settotal();
    }

    getrestaurantdata(){
        this.getloadingstate(true);
        AsyncStorage.getItem('cartitems', (err, cartitems)=>{
            const cartitemsdata = JSON.parse(cartitems);
            const res_id = cartitemsdata[0].restaurant_id;
            SharedPreferences.getItems(['cartprice', 'latitude', 'longitude'], userdata => {
                this.setState({subtotal: userdata[0]});
                //////////////////////////////////////////////* Get selected restaurant data*////////////////////////////////////////////////////
                axios.post(Url.getrestaurantdetailsurl,
                QueryString.stringify({
                    restaurant_id : res_id,
                }),
                {
                    headers: {"Content-Type": "application/x-www-form-urlencoded",}
                })
                .then(response => {
                    const res_data = response.data;
                    const ulat = userdata[1];
                    const ulan = userdata[2];
                    const deliverycharge = Number(response.data.delivery_charge);

                    console.log(res_data)

                    let add_charge = res_data.min_small_order_amount;
                    this.setState({additionalchargename: 'Service Charge'});
                    this.setState({additionalcharge: res_data.min_small_order_amount});
                    if(add_charge == 0){
                        this.setState({additionalchargeavailable : false});
                    }else{
                        this.setState({additionalchargeavailable : true});
                    }

                    this.setState({m_lat : res_data.map_latitude});
                    this.setState({m_lan : res_data.map_longitude});
                    this.getDeliveryCharge(deliverycharge);
                }).catch(error => {
                    console.log(error);
                })
                this.settotal();
            });
        });


        SharedPreferences.getItem('appliedpromo', promo => {
            let appliedpromo = JSON.parse(promo)
            this.setState({promotion: appliedpromo});
            this.settotal();
            if(promo == null){
                this.setState({promovalue: 0});
                this.setState({promoavailable : false});
            }else{
                this.setState({promoavailable : true});
            }
        });
    }

    getordercharges(total){
        this.props.getordercharges(total);
    }

    getchargersarray(array){
        this.props.getchargersarray(array);
    }

    getloadingstate(state){
        this.props.getloadingstate(state);
    }

    settotal() {
        let d_type = this.props.ordertype;
        let s_total = this.state.subtotal;
        let d_charge = this.state.deliverycharge;
        let a_charge = this.state.additionalcharge;
        let appliedpromocode = this.state.promotion;

        var new_total = Number(s_total)+Number(d_charge)+Number(a_charge);
            this.setState({total: new_total});
            this.checkpromotype(this.state.promotion);

        if(d_type == 0){
            var new_total = Number(s_total)+Number(d_charge)+Number(a_charge);
            this.setState({total: new_total});
            this.checkpromotype(this.state.promotion);
        }else if(d_type == 1){
            var new_total = Number(s_total)+Number(a_charge);
            this.setState({total: new_total});
            this.setState({deliverycharge: 0});
            this.checkpromotype(this.state.promotion);
        }else if(d_type == 2){
            var new_total = Number(s_total)+Number(a_charge);
            this.setState({total: new_total});
            this.setState({deliverycharge: 0});
            this.checkpromotype(this.state.promotion);
        }
        setTimeout(() => {this.getloadingstate(false)}, 1000);
    }

    checkpromotype(promo){
        if(promo){
            if(promo.promo_type == 'valuediscount'){
                this.settotalforvaluepromo(promo);
                setTimeout(() => {this.getloadingstate(false)}, 1000);
            }else if(promo.promo_type == 'deliveryfree'){
                this.settotalfordeleveryfree(promo);
                this.setState({promoavailable : false});
                setTimeout(() => {this.getloadingstate(false)}, 1000);
            }else if(promo.promo_type == 'percentage'){
                this.settotalforpercentagepromo(promo);
                setTimeout(() => {this.getloadingstate(false)}, 1000);
            }else{
                setTimeout(() => {this.getloadingstate(false)}, 1000);
            }
        }else{
            setTimeout(() => {this.getloadingstate(false)}, 1000);
        }
    }

    /* Calculate Promotion Charges*/

    settotalforvaluepromo(promo){
        let now_total = this.state.total;
        let promo_value = promo.discount_value;
        let minimum_value = promo.minimum_value;

        if(now_total > minimum_value){
            this.setState({promovalue: promo_value});
            let new_total = Number(now_total) - Number(promo_value);
            this.setState({total: new_total});
        }else{
            this.setState({cannotapplypromoalert : true})
        }
    }

    settotalfordeleveryfree(promo){
        let s_total = this.state.subtotal;
        let a_charge = this.state.additionalcharge;

        let now_total = this.state.total;
        let minimum_value = promo.minimum_value;

        if(now_total > minimum_value){
            console.log(now_total, '>', minimum_value)
            this.setState({deliverycharge: 0});
            var new_total = Number(s_total)+Number(a_charge);
            this.setState({total: new_total});
            this.setState({promovalue: 0});
            this.setState({promoavailable: false});
        }else{
            console.log(now_total, '>', minimum_value)
            this.setState({cannotapplypromoalert : true})
        }
    }

    settotalforpercentagepromo(promo){
        let now_total = this.state.total;
        let promo_value = promo.discount_value;
        let minimum_value = promo.minimum_value;
        let new_total = 0;

        if(now_total > minimum_value){
            this.setState({promovalue: promo.promo_value});
            let promovalue = (Number(promo_value)/100) * Number(now_total)
            new_total = Number(now_total)-Number(promovalue);
            const p_value = (Number(promo_value)/100)*Number(now_total);
            this.setState({promovalue : p_value});
            this.setState({total: new_total});
        }else{
            this.setState({cannotapplypromoalert : true})
        }
    }

    render(){
        let {ordertype} = this.props;
        return(
            <View style={[styles.orderchargescontainer]}>
                <Text style={[styles.paymentsummerytext]}>{Languages.PaymentSummery}</Text>

                <View style={{flexDirection : 'row', justifyContent : 'space-between'}}>
                    <Text style={[styles.orderchargestext]}>{Languages.CartTotal}</Text>
                    <Text style={[styles.orderchargestext]}>{Languages.Rs} {Number(this.state.subtotal).toFixed(2)}</Text>
                </View>
                {this.state.promoavailable ?
                <View style={{flexDirection : 'row', justifyContent : 'space-between'}}>
                    <Text style={[styles.orderchargespromotiontext]}>{Languages.Discount}</Text>
                    <Text style={[styles.orderchargespromotiontext]}>{Languages.Rs} -{Number(this.state.promovalue).toFixed(2)}</Text>
                </View> : null}
                {this.state.additionalchargeavailable ? 
                <View style={{flexDirection : 'row', justifyContent : 'space-between'}}>
                    <Text style={[styles.orderchargestext]}>{Languages.ServiceCharge}</Text>
                    <Text style={[styles.orderchargestext]}>{Languages.Rs} {Number(this.state.additionalcharge).toFixed(2)}</Text>
                </View> : null}
                <View style={{flexDirection : 'row', justifyContent : 'space-between'}}>
                    <Text style={[styles.orderchargestext]}>{Languages.DeliveryFee}</Text>
                    <Text style={[styles.orderchargestext]}>{Languages.Rs} {Number(this.state.deliverycharge).toFixed(2)}</Text>
                </View>
                <View style={{flexDirection : 'row', justifyContent : 'space-between', marginTop : 10}}>
                    <Text style={[styles.orderchargestext, {fontFamily : Constants.fontFamilybold}]}>{Languages.TotalAmount}</Text>
                    <Text style={[styles.orderchargestext, {fontFamily : Constants.fontFamilybold}]}>{Languages.Rs} {Number(this.state.total).toFixed(2)}</Text>
                </View>
                
                {/* Cannot apply promo code alert */}
                <CustomAlert
                    displayMode={'error'}
                    displayMsg={Languages.CannotApplySelectedPromoCode}
                    displaymsgtitle={'Error'}
                    visibility={this.state.cannotapplypromoalert}
                    cancellable={false}
                    buttons={(
                    <>
                        <CustomAlertButton buttontitle={'Ok'} theme={'error'} buttonaction={()=>this.setState({cannotapplypromoalert : false})}/>
                    </>
                    )}
                >
                </CustomAlert>
            </View>
        );
    }
}

OrderCharges.propTypes = {
    getordercharges: PropTypes.func,
    getloadingstate : PropTypes.func
};

export default OrderCharges;