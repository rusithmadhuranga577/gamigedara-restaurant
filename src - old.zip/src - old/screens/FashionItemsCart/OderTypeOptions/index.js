import React from 'react';
import { Text, View, TouchableOpacity } from 'react-native';
import PropTypes from 'prop-types';
import SegmentedControlTab from "react-native-segmented-control-tab";
import { useNavigation } from '@react-navigation/native';
import { Store, Colors, Url, Languages } from '@common';
import styles from '../styles';
import DeliveryInfoButton from '../DeliveryInfoButton/button';
import UserLocationMapView from '../Components/map';
import { Button, LoadingComponent, CustomAlert, CustomAlertButton } from '@components';
import { showMessage, hideMessage } from "react-native-flash-message";
import axios from 'axios';
import SelectedRestaurent from './selectrestaurant';
import SetShedule from './setshedule';
import EstTimeComponent from '../EstTimeComponent/index';

const QueryString = require('query-string');
var SharedPreferences = require('react-native-shared-preferences');

class OrderTypeOptions extends React.Component {

    constructor(props) {
        super(props);

        this.state = {
            outofrange : false,
            ordertype : 0,
            user_addressline1 : 0,
            user_addressline2 : 0,
            useraddress : '',
            fulladdress : '',
            phonenumber : '',
            cartprice : 0,
            deliveryduration : 0,
            city : '',
            email : '',
            fname : '',
            lname : '',
            outofrangealert : false,
            shedulecontainervisibility : false,
            date : '',
            time : '',
            selected_res_id : '',
            selected_res_data : [],
            infohave : false
        };
        this.getType = this.getType.bind(this);
        this.getNewRestaurant = this.getNewRestaurant.bind(this);
        this.setTime = this.setTime.bind(this);
    }

    componentDidMount() {
        this.setInitialDateTime();
        this.getsharedpreferencesdata();
        this._unsubscribe = this.props.navigation.addListener('focus', () => {
            this.getsharedpreferencesdata();
            this.setInitialDateTime();
        });
    }

    setInitialDateTime = () => {
        var t = new Date(); 

        var date = t.getDate();
        var month = t.getMonth()+1;
        var year = t.getFullYear()
        
        var hours = t.getHours();
        var minutes = t.getMinutes();
        var ampm = hours >= 12 ? 'pm' : 'am';
        hours = hours % 12;
        hours = hours ? hours : 12; // the hour '0' should be '12'
        minutes = minutes < 10 ? '0'+minutes : minutes;
        var strTime = hours + ':' + minutes + ' ' + ampm;

        var fulldate = `${year}-${month}-${date}`;

        this.setState({date : fulldate});
        this.setState({time : strTime});
    }

    getsharedpreferencesdata(){
        const {navigation} = this.props;
        SharedPreferences.getItems(['user_addressline1', 'user_addressline2', 'user_deliverycontact', 'user_city', 'cartprice', 'email', 'fname', 'lname'], userdata => {
            if(userdata[0] == 'null' || userdata[1] == 'null' || userdata[2] == 'null' || userdata[3] == 'null'){
                console.log(userdata)
                this.setState({user_addressline1: ''});
                this.setState({user_addressline2: ''});
                this.setState({phonenumber: ''});
                this.setState({city: ''});
                this.setState({fulladdress : Languages.ClickHereToAddDelivery});
                this.setState({infohave : false});
            }else{
                this.setState({user_addressline1: userdata[0]});
                this.setState({user_addressline2: userdata[1]});
                this.setState({phonenumber: userdata[2]});
                this.setState({city: userdata[3]});
                this.setState({fulladdress : `${userdata[6]} ${userdata[7]} \n${userdata[0]}, ${userdata[1]}, ${userdata[3]} \n${userdata[2]} `});
                this.setState({useraddress : `${userdata[0]}, ${userdata[1]}, ${userdata[3]}`});
                this.setState({infohave : true});
            }

            this.setState({cartprice: userdata[4]});
            this.setState({email: userdata[5]});
            this.setState({fname: userdata[6]});
            this.setState({lname: userdata[7]});
        });
    }

    changedeliverytype(index){
        const {navigation} = this.props;
        if(index == 0){
            if(this.state.outofrange == true){
                showMessage({
                    message:  Languages.DeliveryUnavailable,
                    type: "danger",
                    icon : 'danger',
                    onPress: () => {navigation.navigate('LocationSettings', {logged : 1})},
                    duration : 2500,
                });
            }else{
                this.setState({ordertype : index});
            }
        }else{
            this.setState({ordertype : index});
        }
        console.log(index)
    }

    componentDidUpdate() {
        this.getType();
        const old_res_id = this.state.selected_res_id;
        const new_res_id = this.props.res_id;

        if(old_res_id != new_res_id){
            this.setState({selected_res_id : this.props.res_id});
            this.getNewRestaurantData(new_res_id);
        }
    }

    getNewRestaurantData = (id) => {
        axios.post(Url.getrestaurantdetailsurl, 
        QueryString.stringify({
            restaurant_id : id
        }),
        {
            headers: {"Content-Type": "application/x-www-form-urlencoded",}
        })
        .then(response => {
            console.log('RSETAURANT DATA',response.data);
            this.setState({selected_res_data : response.data});
        }).catch(error => {
            console.log(error);
        })
    }

    getType(){
        this.props.getType(this.state);
    }

    setordertype(type){
        this.state.ordertype = type
    }

    getNewRestaurant(value){
        this.props.getNewRestaurant(value);
    }

    setTime(datetime){
        this.props.setTime(datetime);
    }

    setNewDateTime=(array)=>{
        this.setState({date : array[0].date});
        this.setState({time : array[0].time});
    }

    DeliveryView({lat, lan, address, phonenumber}){
        {
            return(
                <View>
                    <DeliveryInfoButton icon={'map-marker-alt'} title={Languages.DeliveryInfo} subtext={address} page={'LocationSettings'}/>
                    <UserLocationMapView latitude={lat} longitude={lan} getTime={(time)=>this.setState({deliveryduration: time})}/>
                    <DeliveryInfoButton icon={'phone'} title={Languages.DeliveryContact} subtext={phonenumber}/>
                </View>
            );
        }
    }

    render(){
        const shedulevisibility = this.state.shedulecontainervisibility;
        return(
            <View>
                <SegmentedControlTab
                    values={[Languages.Delivery, Languages.SelfPickup]}
                    selectedIndex={this.state.ordertype}
                    onTabPress={(type)=>this.changedeliverytype(type)}
                    tabsContainerStyle={[styles.tabscontainerstyle]}
                    tabStyle={[styles.tabstyle]}
                    activeTabStyle={[styles.activetabstyle]}
                    tabTextStyle={[styles.tabtextstyle]}
                    activeTabTextStyle={[styles.activetabtextstyle]}
                />
                {this.state.ordertype == 0 ?
                <View>
                    <DeliveryInfoButton icon={'map-marker-alt'} date={''} time={''} title={Languages.DeliveryInfo} subtext={this.state.fulladdress} page={'SetAddress'}/>
                    <DeliveryInfoButton icon={'clock'} date={''} time={''} title={Languages.EstTime} subtext={this.state.selected_res_data.fashion_delivery_time} page={''} arrow={false}/>
                </View> : null}
                {this.state.ordertype == 1 ?
                <View style={{marginTop : 20}}>
                </View> : null}

                {shedulevisibility ? 
                <SetShedule res_data={this.state.selected_res_data} hideView={(state)=>this.setState({shedulecontainervisibility : state})} getData={(data)=>(this.setNewDateTime(data))}/>:null}
            </View>
        );
    };
}

OrderTypeOptions.propTypes = {
    getType: PropTypes.func,
};

export default function(props){
    const navigation = useNavigation();
    return <OrderTypeOptions {...props} navigation={navigation} />;
} 